package com.proo.poptimize.mixin;

import com.proo.poptimize.Config;
import com.proo.poptimize.Feature;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** No portal, nausea, pumpkin or powder snow pictures over the screen. */
@Mixin(InGameHud.class)
public class InGameHudMixin {
	@Inject(method = "renderPortalOverlay", at = @At("HEAD"), cancellable = true, require = 0)
	private void poptimize$noPortal(CallbackInfo ci) {
		if (Config.on(Feature.NO_SCREEN_EFFECTS)) {
			ci.cancel();
		}
	}

	@Inject(method = "renderNauseaOverlay", at = @At("HEAD"), cancellable = true, require = 0)
	private void poptimize$noNausea(CallbackInfo ci) {
		if (Config.on(Feature.NO_SCREEN_EFFECTS)) {
			ci.cancel();
		}
	}

	// Used for the carved pumpkin and for powder snow.
	@Inject(method = "renderOverlay", at = @At("HEAD"), cancellable = true, require = 0)
	private void poptimize$noOverlay(CallbackInfo ci) {
		if (Config.on(Feature.NO_SCREEN_EFFECTS)) {
			ci.cancel();
		}
	}
}
