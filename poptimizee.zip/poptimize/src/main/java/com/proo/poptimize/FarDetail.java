package com.proo.poptimize;

import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.render.entity.state.ItemEntityRenderState;
import net.minecraft.client.render.entity.state.ItemFrameEntityRenderState;
import net.minecraft.client.render.entity.state.ItemStackEntityRenderState;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

/** Simpler drawing for far entities. Only the picture of this frame is changed. */
public final class FarDetail {
	private FarDetail() {
	}

	public static boolean isFar(EntityRenderState state, Setting setting) {
		double limit = Config.amount(setting);
		return state.squaredDistanceToCamera > limit * limit;
	}

	public static void apply(Entity entity, EntityRenderState state) {
		if (Config.on(Feature.TWO_ITEM_COPIES) && state instanceof ItemStackEntityRenderState stack) {
			stack.renderedAmount = Math.min(stack.renderedAmount, 2);
		}

		if (Config.on(Feature.FAR_SKIN) && state instanceof PlayerEntityRenderState player
				&& isFar(state, Setting.SKIN_DISTANCE)) {
			player.capeVisible = false;
			player.hatVisible = false;
			player.jacketVisible = false;
			player.leftSleeveVisible = false;
			player.rightSleeveVisible = false;
			player.leftPantsLegVisible = false;
			player.rightPantsLegVisible = false;
		}

		if (!isFar(state, Setting.DETAIL_DISTANCE)) return;

		if (Config.on(Feature.FAR_ANIMATION) && state instanceof LivingEntityRenderState living
				&& !(entity instanceof PlayerEntity) && !Culling.isProtected(entity)) {
			living.limbSwingAnimationProgress = 0.0F;
			living.limbSwingAmplitude = 0.0F;
			living.age = 0.0F;
		}

		// The age drives both the spinning and the bobbing of a dropped item.
		if (Config.on(Feature.FAR_ITEM_SPIN) && state instanceof ItemEntityRenderState item) {
			item.age = 0.0F;
		}

		if (Config.on(Feature.FAR_FRAME_ITEMS) && state instanceof ItemFrameEntityRenderState frame) {
			frame.itemRenderState.clear();
			frame.mapId = null;
		}
	}
}
