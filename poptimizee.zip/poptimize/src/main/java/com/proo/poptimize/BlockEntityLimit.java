package com.proo.poptimize;

import it.unimi.dsi.fastutil.longs.Long2DoubleOpenHashMap;
import net.minecraft.block.entity.BannerBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.DecoratedPotBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.block.entity.SignBlockEntity;
import net.minecraft.block.entity.SkullBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;

import java.util.Arrays;

/**
 * Draws only the nearest chests, signs and similar blocks. Distances seen while drawing are
 * collected for a few ticks, then used as the cut-off. Only used on the render thread.
 */
public final class BlockEntityLimit {
	private static final Long2DoubleOpenHashMap SEEN = new Long2DoubleOpenHashMap();
	private static double cutOff = Double.MAX_VALUE;
	private static int ticks;

	private BlockEntityLimit() {
	}

	public static boolean isOver(BlockEntity blockEntity) {
		if (Config.value(Setting.BLOCK_ENTITY_LIMIT) == 0 || !counts(blockEntity)) return false;

		Entity camera = MinecraftClient.getInstance().getCameraEntity();
		if (camera == null) return false;

		BlockPos pos = blockEntity.getPos();
		double distance = camera.squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
		SEEN.put(pos.asLong(), distance);
		return distance > cutOff;
	}

	private static boolean counts(BlockEntity blockEntity) {
		return blockEntity instanceof ChestBlockEntity
				|| blockEntity instanceof EnderChestBlockEntity
				|| blockEntity instanceof ShulkerBoxBlockEntity
				|| blockEntity instanceof SignBlockEntity
				|| blockEntity instanceof SkullBlockEntity
				|| blockEntity instanceof BannerBlockEntity
				|| blockEntity instanceof DecoratedPotBlockEntity;
	}

	public static void tick(MinecraftClient client) {
		if (++ticks < 5) return;
		ticks = 0;

		int limit = Config.value(Setting.BLOCK_ENTITY_LIMIT);

		if (limit == 0 || client.world == null) {
			cutOff = Double.MAX_VALUE;
		} else if (!SEEN.isEmpty()) {
			if (SEEN.size() > limit) {
				double[] distances = SEEN.values().toDoubleArray();
				Arrays.sort(distances);
				cutOff = distances[limit - 1];
			} else {
				cutOff = Double.MAX_VALUE;
			}
		}

		SEEN.clear();
	}
}
