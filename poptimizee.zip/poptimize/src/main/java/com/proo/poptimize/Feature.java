package com.proo.poptimize;

import java.util.Locale;

/** Everything that has an on/off switch in the menu. */
public enum Feature {
	THREADED_CHUNKS(Category.VIDEO),
	SOLID_LEAVES(Category.VIDEO),
	NO_BIOME_BLEND(Category.VIDEO),
	NO_CHUNK_FADE(Category.VIDEO),
	NO_TEXTURE_FILTER(Category.VIDEO),
	NO_TRANSPARENCY(Category.VIDEO),
	NO_ENTITY_SHADOWS(Category.VIDEO),
	NO_CLOUDS(Category.VIDEO),
	NO_SMOOTH_LIGHT(Category.VIDEO),
	NO_VIGNETTE_BLUR(Category.VIDEO),

	CULL_MOBS(Category.ENTITIES),
	CULL_HIDDEN(Category.ENTITIES),
	CULL_PLAYERS(Category.ENTITIES, false),
	CULL_PLAYER_NAMES(Category.ENTITIES),
	CULL_NAMES(Category.ENTITIES),
	CULL_EQUIPMENT(Category.ENTITIES),
	CULL_ITEMS(Category.ENTITIES),
	CULL_XP(Category.ENTITIES),
	CULL_FRAMES(Category.ENTITIES),
	CULL_PAINTINGS(Category.ENTITIES),
	CULL_STANDS(Category.ENTITIES),
	FAR_ANIMATION(Category.ENTITIES),
	FAR_LAYERS(Category.ENTITIES),
	FAR_ITEM_SPIN(Category.ENTITIES),
	TWO_ITEM_COPIES(Category.ENTITIES),
	FAR_SKIN(Category.ENTITIES),
	FAR_FRAME_ITEMS(Category.ENTITIES),

	CULL_CHESTS(Category.BLOCKS),
	CULL_DECORATIONS(Category.BLOCKS),
	CULL_CAMPFIRE_POTS(Category.BLOCKS),
	CULL_PISTONS(Category.BLOCKS),
	CULL_SIGN_TEXT(Category.BLOCKS),
	CULL_ENCHANT_BOOK(Category.BLOCKS),
	NO_SPAWNER_MOB(Category.BLOCKS),
	NO_BEACON_BEAM(Category.BLOCKS),
	FAR_END_PORTAL(Category.BLOCKS),

	LIMIT_PARTICLES(Category.EFFECTS),
	NO_PARTICLE_PHYSICS(Category.EFFECTS, false),
	NO_FIREWORK_PARTICLES(Category.EFFECTS, false),
	NO_CAMPFIRE_SMOKE(Category.EFFECTS),
	FEWER_PORTAL_PARTICLES(Category.EFFECTS),
	NO_AMBIENT(Category.EFFECTS),
	NO_WEATHER(Category.EFFECTS),
	NO_RAIN_SPLASH(Category.EFFECTS),
	NO_ANIMATIONS(Category.EFFECTS),
	LIMIT_SOUNDS(Category.EFFECTS),
	NO_FIRE(Category.EFFECTS),
	NO_SCREEN_EFFECTS(Category.EFFECTS, false),
	NO_TOASTS(Category.EFFECTS),
	CLEAR_FLUID_FOG(Category.EFFECTS, false),

	BACKGROUND_FPS(Category.SMART),

	RECORDING_MODE(Category.TOOLS, false),
	STREAMER_MODE(Category.TOOLS, false),
	FULLBRIGHT(Category.TOOLS, false),
	ZOOM_TOGGLE(Category.TOOLS),
	FPS_COUNTER(Category.TOOLS),
	COORDINATES(Category.TOOLS),
	TIMER(Category.TOOLS);

	/** The menu tabs. Features and {@link Setting}s are listed under one of them. */
	public enum Category {
		VIDEO, ENTITIES, BLOCKS, EFFECTS, SMART, TOOLS
	}

	public final Category category;
	public final boolean defaultOn;

	Feature(Category category) {
		this(category, true);
	}

	Feature(Category category, boolean defaultOn) {
		this.category = category;
		this.defaultOn = defaultOn;
	}

	public String translationKey() {
		return "poptimize.feature." + name().toLowerCase(Locale.ROOT);
	}
}
