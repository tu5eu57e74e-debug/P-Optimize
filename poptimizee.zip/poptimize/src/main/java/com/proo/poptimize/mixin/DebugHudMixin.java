package com.proo.poptimize.mixin;

import com.proo.poptimize.Config;
import net.minecraft.client.gui.hud.DebugHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Streamer mode: the F3 screen would show the coordinates. */
@Mixin(DebugHud.class)
public class DebugHudMixin {
	@Inject(method = "render", at = @At("HEAD"), cancellable = true, require = 0)
	private void poptimize$hide(CallbackInfo ci) {
		if (Config.streaming()) {
			ci.cancel();
		}
	}
}
