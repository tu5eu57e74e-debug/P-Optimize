package com.proo.poptimize;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.world.LightType;
import net.minecraft.world.World;

/** Lower render distance underground, and a low frame rate while the player is away. */
public final class AutoModes {
	/** Ticks underground, or above ground, before the render distance changes. */
	private static final int ENTER_TICKS = 100;
	private static final int LEAVE_TICKS = 60;

	private static boolean underground;
	private static int changingTicks;

	private static boolean away;
	private static int idleTicks;
	private static double x;
	private static double y;
	private static double z;
	private static float yaw;
	private static float pitch;

	private AutoModes() {
	}

	/** The render distance to use right now because the player is underground, or 0. */
	public static int undergroundDistance() {
		return underground ? Config.value(Setting.UNDERGROUND_DISTANCE) : 0;
	}

	public static boolean away() {
		return away && Config.value(Setting.AFK_MINUTES) != 0;
	}

	public static void tick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;

		if (client.world == null || player == null) {
			away = false;
			idleTicks = 0;
			changingTicks = 0;

			if (underground) {
				underground = false;
				VideoSettings.applyRenderDistance(client);
			}

			return;
		}

		tickUnderground(client, player);
		tickAway(client, player);
	}

	private static void tickUnderground(MinecraftClient client, ClientPlayerEntity player) {
		// Underground means: in the overworld, low enough and with no light from the sky.
		boolean below = Config.value(Setting.UNDERGROUND_DISTANCE) != 0
				&& World.OVERWORLD.equals(client.world.getRegistryKey())
				&& player.getY() < Config.selected(Setting.UNDERGROUND_Y)
				&& client.world.getLightLevel(LightType.SKY, player.getBlockPos().up()) == 0;

		if (below == underground) {
			changingTicks = 0;
		} else if (++changingTicks >= (below ? ENTER_TICKS : LEAVE_TICKS)) {
			underground = below;
			changingTicks = 0;
			VideoSettings.applyRenderDistance(client);
		}
	}

	private static void tickAway(MinecraftClient client, ClientPlayerEntity player) {
		int minutes = Config.value(Setting.AFK_MINUTES);
		boolean still = player.getX() == x && player.getY() == y && player.getZ() == z
				&& player.getYaw() == yaw && player.getPitch() == pitch;

		x = player.getX();
		y = player.getY();
		z = player.getZ();
		yaw = player.getYaw();
		pitch = player.getPitch();

		if (minutes == 0 || !still) {
			away = false;
			idleTicks = 0;
			return;
		}

		if (!away && ++idleTicks >= minutes * 60 * 20) {
			away = true;
			client.inGameHud.setOverlayMessage(Text.translatable("poptimize.afk"), false);
		}
	}
}
