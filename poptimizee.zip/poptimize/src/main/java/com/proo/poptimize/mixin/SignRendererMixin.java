package com.proo.poptimize.mixin;

import com.proo.poptimize.Config;
import com.proo.poptimize.Feature;
import com.proo.poptimize.Culling;
import com.proo.poptimize.Setting;
import net.minecraft.client.render.block.entity.AbstractSignBlockEntityRenderer;
import net.minecraft.client.render.block.entity.state.SignBlockEntityRenderState;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Item 19: the sign stays, its far text is skipped. */
@Mixin(AbstractSignBlockEntityRenderer.class)
public class SignRendererMixin {
	@Inject(method = "renderText", at = @At("HEAD"), cancellable = true)
	private void poptimize$skipText(SignBlockEntityRenderState state, MatrixStack matrices,
			OrderedRenderCommandQueue queue, boolean front, CallbackInfo ci) {
		if (Config.on(Feature.CULL_SIGN_TEXT) && Culling.isBeyond(state.pos, Config.amount(Setting.DIST_SIGN_TEXT))) {
			ci.cancel();
		}
	}
}
