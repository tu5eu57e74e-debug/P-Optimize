package com.proo.poptimize.mixin;

import com.proo.poptimize.Config;
import com.proo.poptimize.Feature;
import net.minecraft.client.particle.Particle;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Particles stop testing for blocks when they move. */
@Mixin(Particle.class)
public class ParticleMixin {
	@Shadow
	protected boolean collidesWithWorld;

	@Inject(method = "move(DDD)V", at = @At("HEAD"), require = 0)
	private void poptimize$noPhysics(CallbackInfo ci) {
		if (Config.on(Feature.NO_PARTICLE_PHYSICS)) {
			this.collidesWithWorld = false;
		}
	}
}
