package com.proo.poptimize;

import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;

import java.util.HashMap;
import java.util.Map;

/** Limits copies of the same sound that start close together, and sounds per second. */
public final class SoundLimit {
	private static final long WINDOW_MS = 250;

	private static final Map<SoundEvent, Integer> COUNTS = new HashMap<>();
	private static long windowStart;
	private static long secondStart;
	private static int inSecond;

	private SoundLimit() {
	}

	public static synchronized boolean allow(SoundEvent event, SoundCategory category) {
		if (!Config.on(Feature.LIMIT_SOUNDS)) return true;

		boolean mobOrBlock = category == SoundCategory.HOSTILE || category == SoundCategory.NEUTRAL
				|| category == SoundCategory.BLOCKS;

		// Music, records, players and the interface are never limited.
		if (!mobOrBlock && category != SoundCategory.AMBIENT && category != SoundCategory.WEATHER) {
			return true;
		}

		long now = System.nanoTime() / 1_000_000L;

		if (mobOrBlock) {
			if (now - windowStart >= WINDOW_MS) {
				windowStart = now;
				COUNTS.clear();
			}

			if (COUNTS.merge(event, 1, Integer::sum) > Config.selected(Setting.SAME_SOUND_LIMIT)) return false;
		}

		int perSecond = Config.value(Setting.SOUND_LIMIT);
		if (perSecond == 0) return true;

		if (now - secondStart >= 1000) {
			secondStart = now;
			inSecond = 0;
		}

		return ++inSecond <= perSecond;
	}
}
