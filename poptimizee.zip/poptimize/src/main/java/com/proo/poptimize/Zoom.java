package com.proo.poptimize;

/** Zoom state, controlled by the zoom key. */
public final class Zoom {
	public static boolean active;

	private Zoom() {
	}
}
