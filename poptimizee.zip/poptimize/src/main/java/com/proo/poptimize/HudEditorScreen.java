package com.proo.poptimize;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/** Drag the counters to where you want them. */
public class HudEditorScreen extends Screen {
	private final Screen parent;
	private HudItem dragged;
	private int grabX;
	private int grabY;

	public HudEditorScreen(Screen parent) {
		super(Text.translatable("poptimize.action.hud"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		this.addDrawableChild(ButtonWidget.builder(Text.translatable("gui.done"), button -> this.close())
				.dimensions(this.width / 2 - 82, this.height - 28, 80, 20)
				.build());
		this.addDrawableChild(ButtonWidget.builder(Text.translatable("controls.reset"), button -> {
			for (HudItem item : HudItem.values()) {
				item.reset();
			}
		}).dimensions(this.width / 2 + 2, this.height - 28, 80, 20).build());
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);
		context.drawCenteredTextWithShadow(this.textRenderer, Text.translatable("poptimize.hud.help"),
				this.width / 2, this.height - 42, 0xFFFFFFFF);

		for (HudItem item : HudItem.values()) {
			Hud.draw(context, this.client, item);
		}
	}

	@Override
	public boolean mouseClicked(Click click, boolean doubled) {
		for (HudItem item : HudItem.values()) {
			int width = Hud.width(this.client, Hud.text(this.client, item));
			int x = Math.max(0, Math.min(item.x(), this.width - width));
			int y = Math.max(0, Math.min(item.y(), this.height - Hud.HEIGHT));

			// A little extra room around each counter makes it easier to grab with a finger.
			if (click.x() >= x - 4 && click.x() < x + width + 4
					&& click.y() >= y - 4 && click.y() < y + Hud.HEIGHT + 4) {
				this.dragged = item;
				this.grabX = (int) click.x() - x;
				this.grabY = (int) click.y() - y;
				return true;
			}
		}

		return super.mouseClicked(click, doubled);
	}

	@Override
	public boolean mouseDragged(Click click, double offsetX, double offsetY) {
		if (this.dragged == null) return super.mouseDragged(click, offsetX, offsetY);

		int width = Hud.width(this.client, Hud.text(this.client, this.dragged));
		int x = Math.max(0, Math.min((int) click.x() - this.grabX, this.width - width));
		int y = Math.max(0, Math.min((int) click.y() - this.grabY, this.height - Hud.HEIGHT));
		this.dragged.move(x, y);
		return true;
	}

	@Override
	public boolean mouseReleased(Click click) {
		this.dragged = null;
		return super.mouseReleased(click);
	}

	@Override
	public void close() {
		this.client.setScreen(this.parent);
	}

	@Override
	public void removed() {
		Config.save();
	}
}
