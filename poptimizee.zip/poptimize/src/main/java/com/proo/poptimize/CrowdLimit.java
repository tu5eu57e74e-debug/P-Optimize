package com.proo.poptimize;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.FallingBlockEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.TntEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Draws only some of the entities piled in one block, and only the nearest of some kinds. */
public final class CrowdLimit {
	private record Key(long position, EntityType<?> type) {
	}

	private static final Set<Entity> HIDDEN = Collections.newSetFromMap(new IdentityHashMap<>());
	private static int ticks;

	private CrowdLimit() {
	}

	public static boolean isHidden(Entity entity) {
		return !HIDDEN.isEmpty() && HIDDEN.contains(entity);
	}

	public static void tick(MinecraftClient client) {
		if (++ticks < 5) return;
		ticks = 0;
		HIDDEN.clear();

		int stackLimit = Config.value(Setting.STACK_LIMIT);
		int dropLimit = Config.value(Setting.DROP_LIMIT);
		int mobLimit = Config.value(Setting.MOB_LIMIT);
		int xpLimit = Config.value(Setting.XP_LIMIT);
		int tntLimit = Config.value(Setting.TNT_LIMIT);

		if (client.world == null || client.player == null
				|| (stackLimit == 0 && dropLimit == 0 && mobLimit == 0 && xpLimit == 0 && tntLimit == 0)) {
			return;
		}

		Map<Key, Integer> piles = new HashMap<>();
		List<Entity> drops = new ArrayList<>();
		List<Entity> mobs = new ArrayList<>();
		List<Entity> orbs = new ArrayList<>();
		List<Entity> blasts = new ArrayList<>();

		for (Entity entity : client.world.getEntities()) {
			// Players, bosses, named, glowing and ridden entities always stay visible.
			if (Culling.isProtected(entity) || entity.hasCustomName() || entity.isGlowing()
					|| entity.hasPassengers()) {
				continue;
			}

			if (entity instanceof TntEntity || entity instanceof FallingBlockEntity) {
				if (tntLimit != 0) blasts.add(entity);
				continue;
			}

			boolean pileable = entity instanceof ItemEntity
					|| entity instanceof ExperienceOrbEntity
					|| (entity instanceof LivingEntity && !(entity instanceof PlayerEntity));

			if (!pileable) continue;

			if (stackLimit != 0) {
				Key key = new Key(entity.getBlockPos().asLong(), entity.getType());

				if (piles.merge(key, 1, Integer::sum) > stackLimit) {
					HIDDEN.add(entity);
					continue;
				}
			}

			if (entity instanceof ItemEntity) {
				if (dropLimit != 0) drops.add(entity);
			} else if (entity instanceof ExperienceOrbEntity) {
				if (xpLimit != 0) orbs.add(entity);
			} else if (mobLimit != 0 && !(entity instanceof ArmorStandEntity)) {
				mobs.add(entity);
			}
		}

		keepNearest(client.player, drops, dropLimit);
		keepNearest(client.player, mobs, mobLimit);
		keepNearest(client.player, orbs, xpLimit);
		keepNearest(client.player, blasts, tntLimit);
	}

	private static void keepNearest(Entity player, List<Entity> entities, int limit) {
		if (limit == 0 || entities.size() <= limit) return;

		entities.sort(Comparator.comparingDouble(
				(Entity entity) -> entity.squaredDistanceTo(player.getX(), player.getY(), player.getZ())));
		HIDDEN.addAll(entities.subList(limit, entities.size()));
	}
}
