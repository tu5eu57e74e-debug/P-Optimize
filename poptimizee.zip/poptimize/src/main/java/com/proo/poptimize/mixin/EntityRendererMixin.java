package com.proo.poptimize.mixin;

import com.proo.poptimize.Config;
import com.proo.poptimize.FarDetail;
import com.proo.poptimize.Feature;
import com.proo.poptimize.Setting;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Far name tags, the fire on burning entities and less detail far away. */
@Mixin(EntityRenderer.class)
public class EntityRendererMixin {
	@Inject(
			method = "updateRenderState(Lnet/minecraft/entity/Entity;Lnet/minecraft/client/render/entity/state/EntityRenderState;F)V",
			at = @At("RETURN"))
	private void poptimize$hideNames(Entity entity, EntityRenderState state, float tickProgress, CallbackInfo ci) {
		if (Config.on(Feature.NO_FIRE)) {
			state.onFire = false;
		}

		Feature feature = entity instanceof PlayerEntity ? Feature.CULL_PLAYER_NAMES : Feature.CULL_NAMES;
		if (Config.on(feature) && FarDetail.isFar(state, Setting.DIST_NAMES)) {
			state.displayName = null;
		}
	}

	@Inject(
			method = "getAndUpdateRenderState(Lnet/minecraft/entity/Entity;F)Lnet/minecraft/client/render/entity/state/EntityRenderState;",
			at = @At("RETURN"), require = 0)
	private void poptimize$farDetail(Entity entity, float tickProgress,
			CallbackInfoReturnable<EntityRenderState> cir) {
		if (Config.enabled) {
			FarDetail.apply(entity, cir.getReturnValue());
		}
	}
}
