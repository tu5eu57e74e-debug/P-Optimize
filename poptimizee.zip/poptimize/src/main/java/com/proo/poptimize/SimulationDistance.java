package com.proo.poptimize;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;

/**
 * Lower simulation distance than the game's own menu allows (singleplayer and LAN host only).
 * The player's video setting is not touched.
 */
public final class SimulationDistance {
	private static boolean overriding;
	private static int ticks;

	private SimulationDistance() {
	}

	public static void tick(MinecraftServer server) {
		int wanted = Config.value(Setting.SIMULATION_DISTANCE);

		if (wanted == 0 && !overriding) return;

		// Once a second is enough to win over changes made by the game itself.
		if (++ticks < 20) return;
		ticks = 0;

		int distance = wanted != 0 ? wanted : server.getPlayerManager().getSimulationDistance();

		for (ServerWorld world : server.getWorlds()) {
			world.getChunkManager().applySimulationDistance(distance);
		}

		overriding = wanted != 0;
	}
}
