package com.proo.poptimize;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Language;
import net.minecraft.util.Util;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Supplier;

/**
 * The in-game menu, drawn by hand with plain rectangles so it stays light. Side tabs, a
 * smoothly scrolling list, sliders, search, favorites and an explanation for each entry.
 * Every clickable area is recorded while drawing. Works with a mouse or a finger.
 */
public class MenuScreen extends Screen {
	private static final Identifier ICON = Identifier.of("poptimize", "icon.png");

	private static final int PANEL = 0xFF111118;
	private static final int SIDE = 0xFF0C0C12;
	private static final int HEADER_COLOR = 0xFF171720;
	private static final int CARD = 0xFF1B1B25;
	private static final int CARD_HOVER = 0xFF252532;
	private static final int CHIP = 0xFF2D2D3C;
	private static final int TRACK_OFF = 0xFF41415A;
	private static final int WHITE = 0xFFFFFFFF;
	private static final int TEXT = 0xFFE8E8F0;
	private static final int MUTED = 0xFF9696AC;

	private static final int HEADER = 30;
	private static final int FOOTER = 24;
	private static final int CARD_HEIGHT = 32;
	private static final int GAP = 4;
	private static final int DRAG_START = 4;

	// 7 x 7 pixel icons.
	private static final String[] STAR = {
			"...#...", "...#...", "#######", ".#####.", "..###..", ".##.##.", ".#...#."};
	private static final String[] STAR_EMPTY = {
			"...#...", "..#.#..", "###.###", "#.....#", ".#...#.", "#..#..#", "##...##"};

	private enum Tab {
		FAVORITES(null, STAR),
		VIDEO(Feature.Category.VIDEO, new String[] {
				"#######", "#.....#", "#.....#", "#.....#", "#######", "...#...", ".#####."}),
		ENTITIES(Feature.Category.ENTITIES, new String[] {
				"..###..", "..###..", "...#...", ".#####.", "#.###.#", "..#.#..", ".##.##."}),
		BLOCKS(Feature.Category.BLOCKS, new String[] {
				"#######", "#..#..#", "#..#..#", "#######", "#..#..#", "#..#..#", "#######"}),
		EFFECTS(Feature.Category.EFFECTS, new String[] {
				"...#...", ".#.#.#.", "..###..", "###.###", "..###..", ".#.#.#.", "...#..."}),
		SMART(Feature.Category.SMART, new String[] {
				"....##.", "...##..", "..##...", ".#####.", "...##..", "..##...", ".##...."}),
		TOOLS(Feature.Category.TOOLS, new String[] {
				"..#.#..", ".#####.", "##...##", ".#...#.", "##...##", ".#####.", "..#.#.."});

		final Feature.Category category;
		final String[] icon;

		Tab(Feature.Category category, String[] icon) {
			this.category = category;
			this.icon = icon;
		}
	}

	/** A button card. If confirm is true it has to be pressed twice. */
	private record Command(String key, Supplier<Text> label, boolean explained, boolean confirm, Runnable run) {
	}

	/** One card of the list: a switch, a slider or a button. Exactly one field is set. */
	private record Entry(Feature feature, Setting setting, Command command) {
		String favoriteKey() {
			if (this.feature != null) return "feature:" + this.feature.name();
			return this.setting != null ? "setting:" + this.setting.name() : null;
		}

		Text name() {
			if (this.feature != null) return Text.translatable(this.feature.translationKey());
			if (this.setting != null) return Text.translatable(this.setting.translationKey());
			return this.command.label().get();
		}

		/** Translation key of the explanation, or null. */
		String explanationKey() {
			if (this.feature != null) return this.feature.translationKey() + ".desc";
			if (this.setting != null) return this.setting.translationKey() + ".desc";
			return this.command.explained() ? this.command.key() + ".desc" : null;
		}
	}

	/** Something clickable. Sliders also remember where their track is. */
	private record Area(int x, int y, int width, int height, boolean inList, Runnable action,
			Setting slider, int trackX, int trackWidth) {
		boolean contains(double px, double py) {
			return px >= this.x && px < this.x + this.width && py >= this.y && py < this.y + this.height;
		}
	}

	private enum Drag {
		NONE, SCROLL, SLIDE, CANCELLED
	}

	private final Screen parent;
	private final String version;
	private final List<Area> areas = new ArrayList<>();
	/** How far each switch knob has moved, from 0 (off) to 1 (on). */
	private final Map<Feature, Float> knobs = new EnumMap<>(Feature.class);

	private Tab tab = Tab.VIDEO;
	private TextFieldWidget searchField;
	private String search = "";
	private Entry explained;
	private boolean videoChanged;

	private float scroll;
	private float scrollTarget;
	private int maxScroll;

	private boolean pressing;
	private Drag drag = Drag.NONE;
	private Area pressed;
	private double pressX;
	private double pressY;
	private float pressScroll;

	private String confirming;
	private long confirmingAt;
	private Text message;
	private long messageAt;

	private long openedAt;
	private long lastFrame;
	private float seconds;
	private int mouseX;
	private int mouseY;

	private int panelX;
	private int panelY;
	private int panelWidth;
	private int panelHeight;
	private int sideWidth;
	private int listX;
	private int listY;
	private int listWidth;
	private int listHeight;

	public MenuScreen(Screen parent) {
		super(Text.literal("P-Optimize"));
		this.parent = parent;
		this.version = FabricLoader.getInstance().getModContainer("poptimize")
				.map(mod -> "v" + mod.getMetadata().getVersion().getFriendlyString())
				.orElse("");
	}

	private void layout() {
		this.panelWidth = Math.min(460, this.width - 8);
		this.panelHeight = Math.min(280, this.height - 8);
		this.panelX = (this.width - this.panelWidth) / 2;
		this.panelY = (this.height - this.panelHeight) / 2;
		this.sideWidth = this.panelWidth >= 300 ? 80 : 20;
		this.listX = this.panelX + this.sideWidth + 5;
		this.listY = this.panelY + HEADER + 4;
		this.listWidth = this.panelWidth - this.sideWidth - 9;
		this.listHeight = this.panelHeight - HEADER - FOOTER - 5;
	}

	private int searchX() {
		return this.panelX + (this.panelWidth >= 300 ? 104 : 30);
	}

	private int searchWidth() {
		return this.panelX + this.panelWidth - 76 - searchX();
	}

	@Override
	protected void init() {
		layout();
		this.searchField = new TextFieldWidget(this.textRenderer, searchX() + 6, this.panelY + 11,
				Math.max(20, searchWidth() - 12), 10, Text.translatable("poptimize.search"));
		this.searchField.setDrawsBackground(false);
		this.searchField.setMaxLength(40);
		this.searchField.setText(this.search);
		this.searchField.setPlaceholder(Text.translatable("poptimize.search"));
		this.searchField.setChangedListener(text -> {
			this.search = text;
			this.scroll = 0;
			this.scrollTarget = 0;
		});
		this.addSelectableChild(this.searchField);
		this.pressing = false;
	}

	// ---------------------------------------------------------------- entries

	private List<Entry> entries() {
		List<Entry> result = new ArrayList<>();
		String query = normalize(this.search.trim());

		if (!query.isEmpty()) {
			for (Tab each : Tab.values()) {
				for (Entry entry : entriesOf(each)) {
					if (matches(entry, query)) result.add(entry);
				}
			}
		} else if (this.tab == Tab.FAVORITES) {
			for (Tab each : Tab.values()) {
				for (Entry entry : entriesOf(each)) {
					String key = entry.favoriteKey();
					if (key != null && Config.isFavorite(key)) result.add(entry);
				}
			}
		} else {
			result.addAll(entriesOf(this.tab));
		}

		return result;
	}

	private List<Entry> entriesOf(Tab each) {
		List<Entry> result = new ArrayList<>();
		if (each.category == null) return result;

		if (each == Tab.SMART) {
			for (Mode mode : Mode.values()) {
				result.add(command(new Command(mode.translationKey(),
						() -> Text.translatable(mode.translationKey()), true, true, () -> {
							mode.apply();
							this.videoChanged = true;
							show(Text.translatable("poptimize.message.applied"));
						})));
			}
		}

		for (Feature feature : Feature.values()) {
			if (feature.category != each.category) continue;

			result.add(new Entry(feature, null, null));

			// Its settings come right after it.
			for (Setting setting : Setting.values()) {
				if (setting.parent == feature) result.add(new Entry(null, setting, null));
			}
		}

		for (Setting setting : Setting.values()) {
			if (setting.category == each.category && setting.parent == null) {
				result.add(new Entry(null, setting, null));
			}
		}

		if (each == Tab.TOOLS) addTools(result);

		return result;
	}

	private void addTools(List<Entry> result) {
		result.add(command(new Command("poptimize.action.timer_toggle",
				() -> Text.translatable(Timer.running()
						? "poptimize.action.timer_stop" : "poptimize.action.timer_start", Timer.display()),
				false, false, Timer::toggle)));
		result.add(command(new Command("poptimize.action.timer_reset",
				() -> Text.translatable("poptimize.action.timer_reset"), false, false, Timer::reset)));
		result.add(command(new Command("poptimize.action.hud",
				() -> Text.translatable("poptimize.action.hud"), false, false,
				() -> this.client.setScreen(new HudEditorScreen(this)))));
		result.add(command(new Command("poptimize.action.benchmark",
				() -> Text.translatable("poptimize.action.benchmark"), true, false, () -> {
					// Only makes sense inside a world.
					if (this.client.world != null) {
						Benchmark.start();
						this.client.setScreen(null);
					} else {
						show(Text.translatable("poptimize.message.need_world"));
					}
				})));
		result.add(command(new Command("poptimize.action.theme",
				() -> Text.translatable("poptimize.action.theme",
						Text.translatable("poptimize.theme." + Config.theme.name().toLowerCase(Locale.ROOT))),
				false, false, () -> {
					Theme[] themes = Theme.values();
					Config.theme = themes[(Config.theme.ordinal() + 1) % themes.length];
				})));
		result.add(command(new Command("poptimize.action.export",
				() -> Text.translatable("poptimize.action.export"), true, false, () -> {
					this.client.keyboard.setClipboard(Share.write());
					show(Text.translatable("poptimize.message.copied"));
				})));
		result.add(command(new Command("poptimize.action.import",
				() -> Text.translatable("poptimize.action.import"), true, true, () -> {
					if (Share.read(this.client.keyboard.getClipboard())) {
						Timer.reset();
						this.videoChanged = true;
						show(Text.translatable("poptimize.message.applied"));
					} else {
						show(Text.translatable("poptimize.message.bad_text"));
					}
				})));
	}

	private static Entry command(Command command) {
		return new Entry(null, null, command);
	}

	private static boolean matches(Entry entry, String query) {
		if (normalize(entry.name().getString()).contains(query)) return true;

		String key = entry.favoriteKey();
		return key != null && normalize(key.substring(key.indexOf(':') + 1).replace('_', ' ')).contains(query);
	}

	/** Ignores case and the Arabic letter forms people often type differently. */
	private static String normalize(String text) {
		return text.toLowerCase(Locale.ROOT)
				.replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
				.replace('ة', 'ه').replace('ى', 'ي');
	}

	private void show(Text text) {
		this.message = text;
		this.messageAt = Util.getMeasuringTimeMs();
	}

	// ---------------------------------------------------------------- drawing

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		layout();
		this.mouseX = mouseX;
		this.mouseY = mouseY;
		this.areas.clear();

		long now = Util.getMeasuringTimeMs();
		this.seconds = this.lastFrame == 0 ? 0.016F : Math.min(0.1F, (now - this.lastFrame) / 1000.0F);
		this.lastFrame = now;
		if (this.openedAt == 0) this.openedAt = now;

		// Short slide up when the menu opens.
		float open = Math.min(1.0F, (now - this.openedAt) / 180.0F);
		float eased = 1.0F - (1.0F - open) * (1.0F - open) * (1.0F - open);

		context.fill(0, 0, this.width, this.height, Math.round(0x90 * eased) << 24);

		context.getMatrices().pushMatrix();
		context.getMatrices().translate(0.0F, (1.0F - eased) * 16.0F);

		roundRect(context, this.panelX - 1, this.panelY - 1, this.panelWidth + 2, this.panelHeight + 2, 7,
				blend(PANEL, Config.theme.main, 0.55F));
		roundRect(context, this.panelX, this.panelY, this.panelWidth, this.panelHeight, 6, PANEL);

		drawHeader(context);
		drawSidebar(context);
		drawList(context);
		drawFooter(context);
		this.searchField.render(context, mouseX, mouseY, delta);

		context.getMatrices().popMatrix();

		if (this.explained != null) drawExplanation(context);
	}

	private void drawHeader(DrawContext context) {
		int x = this.panelX;
		int y = this.panelY;

		roundRect(context, x, y, this.panelWidth, HEADER, 6, HEADER_COLOR);
		context.fill(x, y + HEADER - 6, x + this.panelWidth, y + HEADER, HEADER_COLOR);

		// A thin line that fades between the theme colors.
		for (int offset = 0; offset < this.panelWidth; offset += 4) {
			int color = blend(Config.theme.dark, Config.theme.light, (float) offset / this.panelWidth);
			context.fill(x + offset, y + HEADER - 1, x + Math.min(offset + 4, this.panelWidth), y + HEADER, color);
		}

		context.drawTexture(RenderPipelines.GUI_TEXTURED, ICON, x + 5, y + 4, 0.0F, 0.0F, 21, 21, 21, 21);

		if (this.panelWidth >= 300) {
			drawFitted(context, this.title, x + 31, y + 6, 68, WHITE, false);
			Text subtitle = Text.literal(this.version + " | " + this.client.getCurrentFps() + " FPS");
			drawFitted(context, subtitle, x + 31, y + 17, 68, MUTED, false);
		}

		roundRect(context, searchX(), y + 7, searchWidth(), 16, 5,
				this.searchField.isFocused() ? CHIP : CARD);

		// Master switch.
		int switchX = x + this.panelWidth - 30;
		Text state = Text.translatable(Config.enabled ? "poptimize.on" : "poptimize.off");
		drawFitted(context, state, switchX - 40, y + 11, 36, Config.enabled ? TEXT : MUTED, true);
		drawSwitch(context, switchX, y + 9, Config.enabled ? 1.0F : 0.0F);

		addArea(switchX - 42, y + 3, 70, 24, false, () -> {
			Config.enabled = !Config.enabled;
			this.videoChanged = true;
		});
	}

	private void drawSidebar(DrawContext context) {
		int x = this.panelX;
		int top = this.panelY + HEADER;
		int height = this.panelHeight - HEADER;

		roundRect(context, x, top, this.sideWidth, height, 6, SIDE);
		context.fill(x, top, x + this.sideWidth, top + 6, SIDE);
		context.fill(x + this.sideWidth - 6, top, x + this.sideWidth, top + height, SIDE);

		Tab[] tabs = Tab.values();
		int tabHeight = Math.min(24, (height - 6) / tabs.length);

		for (int i = 0; i < tabs.length; i++) {
			Tab each = tabs[i];
			int y = top + 3 + i * tabHeight;
			boolean selected = this.search.isBlank() && this.tab == each;
			boolean hovered = hovered(x + 2, y, this.sideWidth - 4, tabHeight - 1, false);

			if (selected || hovered) {
				roundRect(context, x + 2, y, this.sideWidth - 4, tabHeight - 1, 4, selected ? CARD_HOVER : CARD);
			}

			if (selected) context.fill(x + 2, y + 3, x + 4, y + tabHeight - 4, Config.theme.light);

			int middle = y + (tabHeight - 1) / 2;
			drawIcon(context, each.icon, x + 7, middle - 3, selected ? Config.theme.light : MUTED);

			if (this.sideWidth > 40) {
				Text name = Text.translatable("poptimize.tab." + each.name().toLowerCase(Locale.ROOT));
				drawFitted(context, name, x + 19, middle - 4, this.sideWidth - 23, selected ? WHITE : MUTED, false);
			}

			addArea(x + 2, y, this.sideWidth - 4, tabHeight, false, () -> {
				this.tab = each;
				this.searchField.setText("");
				this.setFocused(null);
				this.scroll = 0;
				this.scrollTarget = 0;
			});
		}
	}

	private void drawList(DrawContext context) {
		List<Entry> entries = entries();
		int columns = this.listWidth >= 270 ? 2 : 1;
		int cardWidth = (this.listWidth - 4 - (columns - 1) * GAP) / columns;
		int rows = (entries.size() + columns - 1) / columns;
		int contentHeight = rows * (CARD_HEIGHT + GAP) - GAP;

		this.maxScroll = Math.max(0, contentHeight - this.listHeight);
		this.scrollTarget = clamp(this.scrollTarget, 0, this.maxScroll);
		this.scroll += (this.scrollTarget - this.scroll) * Math.min(1.0F, this.seconds * 18.0F);
		if (Math.abs(this.scrollTarget - this.scroll) < 0.5F) this.scroll = this.scrollTarget;

		if (entries.isEmpty()) {
			Text empty = Text.translatable(this.search.isBlank()
					? "poptimize.favorites.empty" : "poptimize.search.empty");
			drawFitted(context, empty, this.listX + 4, this.listY + this.listHeight / 2 - 4,
					this.listWidth - 8, MUTED, true);
			return;
		}

		context.enableScissor(this.listX, this.listY, this.listX + this.listWidth, this.listY + this.listHeight);

		for (int i = 0; i < entries.size(); i++) {
			int x = this.listX + (i % columns) * (cardWidth + GAP);
			int y = this.listY + (i / columns) * (CARD_HEIGHT + GAP) - Math.round(this.scroll);

			if (y + CARD_HEIGHT <= this.listY || y >= this.listY + this.listHeight) continue;

			Entry entry = entries.get(i);

			if (entry.feature() != null) {
				drawFeature(context, entry, x, y, cardWidth);
			} else if (entry.setting() != null) {
				drawSlider(context, entry, x, y, cardWidth);
			} else {
				drawCommand(context, entry, x, y, cardWidth);
			}
		}

		context.disableScissor();

		if (this.maxScroll > 0) {
			int barHeight = Math.max(14, this.listHeight * this.listHeight / contentHeight);
			int barY = this.listY + Math.round((this.listHeight - barHeight) * this.scroll / this.maxScroll);
			context.fill(this.listX + this.listWidth - 2, this.listY, this.listX + this.listWidth,
					this.listY + this.listHeight, CARD);
			context.fill(this.listX + this.listWidth - 2, barY, this.listX + this.listWidth, barY + barHeight,
					Config.theme.main);
		}
	}

	private void drawCardBackground(DrawContext context, int x, int y, int width, int accent) {
		roundRect(context, x, y, width, CARD_HEIGHT, 5,
				hovered(x, y, width, CARD_HEIGHT, true) ? CARD_HOVER : CARD);
		context.fill(x, y + 9, x + 2, y + CARD_HEIGHT - 9, accent);
	}

	private void drawFeature(DrawContext context, Entry entry, int x, int y, int width) {
		Feature feature = entry.feature();
		boolean on = Config.isChecked(feature);
		float target = on ? 1.0F : 0.0F;
		float position = this.knobs.getOrDefault(feature, target);
		float step = this.seconds * 9.0F;
		position = position < target ? Math.min(target, position + step) : Math.max(target, position - step);
		this.knobs.put(feature, position);

		drawCardBackground(context, x, y, width, blend(TRACK_OFF, Config.theme.light, position));
		drawFitted(context, entry.name(), x + 8, y + 6, width - 40, on ? WHITE : MUTED, false);
		drawSwitch(context, x + width - 27, y + 5, position);

		addArea(x, y, width, CARD_HEIGHT, true, () -> {
			Config.toggle(feature);

			if (feature.category == Feature.Category.VIDEO || feature == Feature.RECORDING_MODE) {
				this.videoChanged = true;
			}
		});

		drawChips(context, entry, x, y);
	}

	private void drawSlider(DrawContext context, Entry entry, int x, int y, int width) {
		Setting setting = entry.setting();
		int value = Config.selected(setting);
		boolean lit = value != 0 || setting.zero != Setting.Zero.OFF;

		drawCardBackground(context, x, y, width, lit ? Config.theme.light : TRACK_OFF);

		Text shown = valueText(setting, value);
		int valueWidth = Math.min(this.textRenderer.getWidth(shown), width * 45 / 100);
		drawFitted(context, shown, x + width - 8 - valueWidth, y + 6, valueWidth,
				lit ? Config.theme.light : MUTED, false);
		drawFitted(context, entry.name(), x + 8, y + 6, width - valueWidth - 22, TEXT, false);
		drawChips(context, entry, x, y);

		int[] choices = setting.choices();
		int index = 0;

		for (int i = 0; i < choices.length; i++) {
			if (choices[i] == value) index = i;
		}

		int trackX = x + 49;
		int trackWidth = Math.max(10, width - 59);
		int knobX = trackX + Math.round((float) index * trackWidth / (choices.length - 1));

		roundRect(context, trackX, y + 22, trackWidth, 3, 1, TRACK_OFF);
		if (knobX > trackX) context.fill(trackX, y + 22, knobX, y + 25, Config.theme.main);

		// Small marks show where the slider can stop.
		for (int i = 0; i < choices.length; i++) {
			int markX = trackX + Math.round((float) i * trackWidth / (choices.length - 1));
			context.fill(markX, y + 22, markX + 1, y + 25, MUTED);
		}

		roundRect(context, knobX - 4, y + 19, 9, 9, 4, WHITE);

		addArea(x + 44, y + 15, width - 44, CARD_HEIGHT - 15, true, () -> {
		}, setting, trackX, trackWidth);
	}

	private void drawCommand(DrawContext context, Entry entry, int x, int y, int width) {
		Command command = entry.command();
		boolean asking = command.key().equals(this.confirming)
				&& Util.getMeasuringTimeMs() - this.confirmingAt < 3000;

		drawCardBackground(context, x, y, width, Config.theme.main);

		int labelY = command.explained() ? y + 6 : y + 12;
		Text label = asking ? Text.translatable("poptimize.confirm") : entry.name();
		drawFitted(context, label, x + 8, labelY, width - 28, asking ? Config.theme.light : WHITE, false);
		context.drawTextWithShadow(this.textRenderer, Text.literal(">"), x + width - 13, y + 12, Config.theme.light);

		addArea(x, y, width, CARD_HEIGHT, true, () -> {
			if (command.confirm() && !(command.key().equals(this.confirming)
					&& Util.getMeasuringTimeMs() - this.confirmingAt < 3000)) {
				this.confirming = command.key();
				this.confirmingAt = Util.getMeasuringTimeMs();
				return;
			}

			this.confirming = null;
			command.run().run();
		});

		if (command.explained()) drawExplainChip(context, entry, x + 7, y + 18);
	}

	/** The explanation button and the favorite star under the name. */
	private void drawChips(DrawContext context, Entry entry, int x, int y) {
		drawExplainChip(context, entry, x + 7, y + 18);

		String key = entry.favoriteKey();
		boolean favorite = Config.isFavorite(key);
		boolean hovered = hovered(x + 24, y + 16, 18, 16, true);

		roundRect(context, x + 25, y + 18, 15, 11, 3, hovered ? TRACK_OFF : CHIP);
		drawIcon(context, favorite ? STAR : STAR_EMPTY, x + 29, y + 20,
				favorite ? 0xFFFFC83D : MUTED);
		addArea(x + 24, y + 16, 18, 16, true, () -> Config.toggleFavorite(key));
	}

	private void drawExplainChip(DrawContext context, Entry entry, int x, int y) {
		boolean hovered = hovered(x - 3, y - 2, 20, 16, true);

		roundRect(context, x, y, 15, 11, 3, hovered ? Config.theme.main : CHIP);
		context.drawTextWithShadow(this.textRenderer, Text.literal("?"), x + 5, y + 2, hovered ? WHITE : TEXT);
		addArea(x - 3, y - 2, 20, 16, true, () -> this.explained = entry);
	}

	private void drawSwitch(DrawContext context, int x, int y, float position) {
		roundRect(context, x, y, 22, 11, 5, blend(TRACK_OFF, Config.theme.main, position));
		roundRect(context, x + 1 + Math.round(position * 11), y + 1, 9, 9, 4, WHITE);
	}

	private Text valueText(Setting setting, int value) {
		if (value == 0) {
			if (setting.zero == Setting.Zero.OFF) return Text.translatable("poptimize.off");
			if (setting.zero == Setting.Zero.STOPWATCH) return Text.translatable("poptimize.value.stopwatch");

			if (setting.zero == Setting.Zero.AUTO) {
				return Text.translatable("poptimize.value.auto", setting.auto(Config.preset));
			}
		}

		return Text.translatable("poptimize.unit." + setting.unit.name().toLowerCase(Locale.ROOT), value);
	}

	private void drawFooter(DrawContext context) {
		int x = this.listX;
		int y = this.panelY + this.panelHeight - 21;
		Preset[] presets = Preset.values();
		int presetWidth = Math.min(46, (this.listWidth - 52) / presets.length);

		for (int i = 0; i < presets.length; i++) {
			Preset preset = presets[i];
			Text name = Text.translatable("poptimize.preset." + preset.name().toLowerCase(Locale.ROOT));

			drawButton(context, x + i * presetWidth, y, presetWidth - 2, 16, name, Config.preset == preset, () -> {
				Config.preset = preset;
				this.videoChanged = true;
			});
		}

		int doneX = x + this.listWidth - 46;
		drawButton(context, doneX, y, 46, 16, Text.translatable("gui.done"), true, this::close);

		int free = doneX - 6 - (x + presets.length * presetWidth);

		if (this.message != null && Util.getMeasuringTimeMs() - this.messageAt < 2500 && free > 20) {
			drawFitted(context, this.message, x + presets.length * presetWidth + 3, y + 4, free,
					Config.theme.light, true);
		}
	}

	private void drawButton(DrawContext context, int x, int y, int width, int height, Text label, boolean selected,
			Runnable action) {
		boolean hovered = hovered(x, y, width, height, false);
		int color = selected
				? (hovered ? Config.theme.light : Config.theme.main)
				: (hovered ? CARD_HOVER : CARD);

		roundRect(context, x, y, width, height, 5, color);
		drawFitted(context, label, x + 3, y + (height - 8) / 2, width - 6, selected ? WHITE : MUTED, true);
		addArea(x, y, width, height, false, action);
	}

	private void drawExplanation(DrawContext context) {
		// A new layer keeps the box above all text drawn before it.
		context.createNewRootLayer();
		context.fill(0, 0, this.width, this.height, 0xB8000000);

		int width = Math.min(300, this.width - 16);
		List<OrderedText> lines = this.textRenderer.wrapLines(
				Text.translatable(this.explained.explanationKey()), width - 20);
		int height = Math.min(this.height - 8, 52 + lines.size() * 11);
		int x = (this.width - width) / 2;
		int y = (this.height - height) / 2;
		boolean rightToLeft = Language.getInstance().isRightToLeft();

		roundRect(context, x - 1, y - 1, width + 2, height + 2, 7, Config.theme.main);
		roundRect(context, x, y, width, height, 6, PANEL);
		drawFitted(context, this.explained.name(), x + 10, y + 9, width - 20, Config.theme.light, true);

		int lineY = y + 24;

		for (OrderedText line : lines) {
			if (lineY + 10 > y + height - 22) break;

			int lineX = rightToLeft ? x + width - 10 - this.textRenderer.getWidth(line) : x + 10;
			context.drawTextWithShadow(this.textRenderer, line, lineX, lineY, TEXT);
			lineY += 11;
		}

		roundRect(context, x + width / 2 - 30, y + height - 20, 60, 15, 5, Config.theme.main);
		drawFitted(context, Text.translatable("gui.done"), x + width / 2 - 28, y + height - 16, 56, WHITE, true);
	}

	// ---------------------------------------------------------------- drawing helpers

	private boolean hovered(int x, int y, int width, int height, boolean inList) {
		if (this.explained != null || (inList && !isInList(this.mouseX, this.mouseY))) return false;

		return this.mouseX >= x && this.mouseX < x + width && this.mouseY >= y && this.mouseY < y + height;
	}

	private boolean isInList(double x, double y) {
		return x >= this.listX && x < this.listX + this.listWidth
				&& y >= this.listY && y < this.listY + this.listHeight;
	}

	private void addArea(int x, int y, int width, int height, boolean inList, Runnable action) {
		addArea(x, y, width, height, inList, action, null, 0, 0);
	}

	/** Areas of the list are cut to the visible part, so hidden cards cannot be clicked. */
	private void addArea(int x, int y, int width, int height, boolean inList, Runnable action, Setting slider,
			int trackX, int trackWidth) {
		int top = y;
		int bottom = y + height;

		if (inList) {
			top = Math.max(top, this.listY);
			bottom = Math.min(bottom, this.listY + this.listHeight);
		}

		if (bottom > top) {
			this.areas.add(new Area(x, top, width, bottom - top, inList, action, slider, trackX, trackWidth));
		}
	}

	/** Draws text, shrinking it if it is wider than the space it has. */
	private void drawFitted(DrawContext context, Text text, int x, int y, int maxWidth, int color, boolean centered) {
		int textWidth = this.textRenderer.getWidth(text);
		if (textWidth <= 0 || maxWidth <= 0) return;

		float scale = Math.min(1.0F, (float) maxWidth / textWidth);
		float left = centered ? x + (maxWidth - textWidth * scale) / 2.0F : x;

		context.getMatrices().pushMatrix();
		context.getMatrices().translate(left, y + (1.0F - scale) * 4.0F);
		context.getMatrices().scale(scale, scale);
		context.drawTextWithShadow(this.textRenderer, text, 0, 0, color);
		context.getMatrices().popMatrix();
	}

	private static void drawIcon(DrawContext context, String[] rows, int x, int y, int color) {
		for (int row = 0; row < rows.length; row++) {
			for (int column = 0; column < rows[row].length(); column++) {
				if (rows[row].charAt(column) == '#') {
					context.fill(x + column, y + row, x + column + 1, y + row + 1, color);
				}
			}
		}
	}

	/** A filled rectangle with rounded corners. The color should be opaque. */
	private static void roundRect(DrawContext context, int x, int y, int width, int height, int radius, int color) {
		int r = Math.max(0, Math.min(radius, Math.min(width, height) / 2));
		context.fill(x, y + r, x + width, y + height - r, color);

		for (int row = 0; row < r; row++) {
			double distance = r - row - 0.5;
			int inset = r - (int) Math.round(Math.sqrt(r * r - distance * distance));
			context.fill(x + inset, y + row, x + width - inset, y + row + 1, color);
			context.fill(x + inset, y + height - row - 1, x + width - inset, y + height - row, color);
		}
	}

	/** Mixes two opaque colors. */
	private static int blend(int from, int to, float amount) {
		int result = 0xFF000000;

		for (int shift = 0; shift <= 16; shift += 8) {
			int a = (from >> shift) & 0xFF;
			int b = (to >> shift) & 0xFF;
			result |= Math.round(a + (b - a) * amount) << shift;
		}

		return result;
	}

	private static float clamp(float value, float low, float high) {
		return Math.max(low, Math.min(high, value));
	}

	// ---------------------------------------------------------------- input

	private Area areaAt(double x, double y) {
		// The last one drawn is on top.
		for (int i = this.areas.size() - 1; i >= 0; i--) {
			if (this.areas.get(i).contains(x, y)) return this.areas.get(i);
		}

		return null;
	}

	private void slide(Area area, double x) {
		Setting setting = area.slider();
		int[] choices = setting.choices();
		double part = (x - area.trackX()) / area.trackWidth();
		int index = (int) Math.round(Math.max(0.0, Math.min(1.0, part)) * (choices.length - 1));

		if (Config.selected(setting) == choices[index]) return;

		Config.select(setting, choices[index]);

		if (setting == Setting.RENDER_DISTANCE || setting == Setting.UNDERGROUND_DISTANCE) {
			this.videoChanged = true;
		}

		if (setting == Setting.TIMER_MINUTES) Timer.reset();
	}

	@Override
	public boolean mouseClicked(Click click, boolean doubled) {
		if (this.explained != null) {
			// Any click closes the explanation.
			this.explained = null;
			ClickableWidget.playClickSound(this.client.getSoundManager());
			return true;
		}

		if (click.button() != 0) return super.mouseClicked(click, doubled);

		// The whole search box focuses the text field, not only the line of text inside it.
		if (click.x() >= searchX() && click.x() < searchX() + searchWidth()
				&& click.y() >= this.panelY + 7 && click.y() < this.panelY + 23) {
			super.mouseClicked(click, doubled);
			this.setFocused(this.searchField);
			return true;
		}

		this.setFocused(null);

		Area area = areaAt(click.x(), click.y());

		if (area != null && !area.inList()) {
			ClickableWidget.playClickSound(this.client.getSoundManager());
			area.action().run();
			Config.save();
			return true;
		}

		if (area == null && !isInList(click.x(), click.y())) return true;

		// Inside the list, wait: this may be the start of a swipe.
		this.pressing = true;
		this.drag = Drag.NONE;
		this.pressed = area;
		this.pressX = click.x();
		this.pressY = click.y();
		this.pressScroll = this.scroll;
		return true;
	}

	@Override
	public boolean mouseDragged(Click click, double offsetX, double offsetY) {
		if (!this.pressing) return super.mouseDragged(click, offsetX, offsetY);

		if (this.drag == Drag.NONE) {
			double across = Math.abs(click.x() - this.pressX);
			double down = Math.abs(click.y() - this.pressY);

			if (this.pressed != null && this.pressed.slider() != null && across > DRAG_START && across >= down) {
				this.drag = Drag.SLIDE;
			} else if (down > DRAG_START) {
				this.drag = Drag.SCROLL;
			} else if (across > DRAG_START * 3) {
				this.drag = Drag.CANCELLED;
			}
		}

		if (this.drag == Drag.SLIDE) {
			slide(this.pressed, click.x());
		} else if (this.drag == Drag.SCROLL) {
			this.scrollTarget = clamp((float) (this.pressScroll - (click.y() - this.pressY)), 0, this.maxScroll);
			this.scroll = this.scrollTarget;
		}

		return true;
	}

	@Override
	public boolean mouseReleased(Click click) {
		if (!this.pressing) return super.mouseReleased(click);

		this.pressing = false;

		if (this.drag == Drag.NONE && this.pressed != null && this.pressed.contains(click.x(), click.y())) {
			ClickableWidget.playClickSound(this.client.getSoundManager());

			if (this.pressed.slider() != null) {
				slide(this.pressed, click.x());
			} else {
				this.pressed.action().run();
			}
		}

		this.pressed = null;
		Config.save();
		return true;
	}

	@Override
	public boolean mouseScrolled(double x, double y, double horizontal, double vertical) {
		if (this.explained == null && vertical != 0) {
			this.scrollTarget = clamp((float) (this.scrollTarget - vertical * 26), 0, this.maxScroll);
		}

		return true;
	}

	@Override
	public void close() {
		// Escape closes the explanation first.
		if (this.explained != null) {
			this.explained = null;
			return;
		}

		this.client.setScreen(this.parent);
	}

	/** Called however the menu is left. Video settings are applied once, here. */
	@Override
	public void removed() {
		Config.save();

		if (this.videoChanged) {
			this.videoChanged = false;
			VideoSettings.apply(this.client);
		}
	}
}
