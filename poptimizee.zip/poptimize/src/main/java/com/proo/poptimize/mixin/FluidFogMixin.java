package com.proo.poptimize.mixin;

import com.proo.poptimize.Config;
import com.proo.poptimize.Feature;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.fog.FogData;
import net.minecraft.client.render.fog.LavaFogModifier;
import net.minecraft.client.render.fog.WaterFogModifier;
import net.minecraft.client.world.ClientWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Pushes water and lava fog far away. */
@Mixin({WaterFogModifier.class, LavaFogModifier.class})
public class FluidFogMixin {
	@Inject(method = "applyStartEndModifier", at = @At("TAIL"), require = 0)
	private void poptimize$clearFog(FogData data, Camera camera, ClientWorld world, float viewDistance,
			RenderTickCounter tickCounter, CallbackInfo ci) {
		if (Config.on(Feature.CLEAR_FLUID_FOG)) {
			data.environmentalStart = 0.0F;
			data.environmentalEnd = 192.0F;
			data.skyEnd = 192.0F;
			data.cloudEnd = 192.0F;
		}
	}
}
