package com.proo.poptimize;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class POptimizeClient implements ClientModInitializer {
	public static final Logger LOGGER = LoggerFactory.getLogger("poptimize");

	private static boolean openMenu;

	@Override
	public void onInitializeClient() {
		Config.load();
		Hud.register();
		Keys.register();
		ClientTickEvents.END_CLIENT_TICK.register(Keys::tick);
		ClientTickEvents.END_CLIENT_TICK.register(CrowdLimit::tick);
		ClientTickEvents.END_CLIENT_TICK.register(ChunkRange::tick);
		ClientTickEvents.END_CLIENT_TICK.register(BlockEntityLimit::tick);
		ClientTickEvents.END_CLIENT_TICK.register(AutoModes::tick);
		ClientTickEvents.END_CLIENT_TICK.register(Timer::tick);
		ServerTickEvents.END_SERVER_TICK.register(SimulationDistance::tick);

		// Apply once, so later manual changes in the video menu are kept.
		ClientLifecycleEvents.CLIENT_STARTED.register(client -> {
			if (!Config.applied) {
				VideoSettings.apply(client);
			} else if (Config.original("RENDER_DISTANCE") != null) {
				// The game may have closed while the underground distance was in use.
				VideoSettings.applyRenderDistance(client);
			}
		});

		// A touch friendly button in the pause menu and the options screen.
		ScreenEvents.AFTER_INIT.register((client, screen, width, height) -> {
			if (screen instanceof GameMenuScreen || screen instanceof OptionsScreen) {
				Screens.getButtons(screen).add(ButtonWidget
						.builder(Text.literal("P-Optimize"), button -> client.setScreen(new MenuScreen(screen)))
						.dimensions(4, 4, 76, 20)
						.build());
			}
		});

		ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
				dispatcher.register(ClientCommandManager.literal("poptimize").executes(context -> {
					openMenu = true;
					return 1;
				})));

		// Opened on the next tick, after the chat screen has closed.
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			if (openMenu && client.currentScreen == null) {
				openMenu = false;
				client.setScreen(new MenuScreen(null));
			}
		});
	}
}
