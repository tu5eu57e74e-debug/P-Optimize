package com.proo.poptimize.mixin;

import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import com.proo.poptimize.Config;
import com.proo.poptimize.FarDetail;
import com.proo.poptimize.Feature;
import com.proo.poptimize.Setting;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.feature.ArmorFeatureRenderer;
import net.minecraft.client.render.entity.feature.BreezeEyesFeatureRenderer;
import net.minecraft.client.render.entity.feature.EmissiveFeatureRenderer;
import net.minecraft.client.render.entity.feature.EyesFeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.HeldItemFeatureRenderer;
import net.minecraft.client.render.entity.feature.SaddleFeatureRenderer;
import net.minecraft.client.render.entity.feature.StuckObjectsFeatureRenderer;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/** Skips armor, held items and small extra layers on far entities. */
@Mixin(LivingEntityRenderer.class)
public class LivingEntityRendererMixin {
	@WrapWithCondition(method = "render", require = 0, at = @At(value = "INVOKE",
			target = "Lnet/minecraft/client/render/entity/feature/FeatureRenderer;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/client/render/entity/state/EntityRenderState;FF)V"))
	private boolean poptimize$skipEquipment(FeatureRenderer<?, ?> feature, MatrixStack matrices,
			OrderedRenderCommandQueue queue, int light, EntityRenderState state, float limbAngle,
			float limbDistance) {
		if (Config.on(Feature.CULL_EQUIPMENT) && FarDetail.isFar(state, Setting.DIST_EQUIPMENT)
				&& (feature instanceof ArmorFeatureRenderer || feature instanceof HeldItemFeatureRenderer)) {
			return false;
		}

		// Glowing eyes, saddles, stuck arrows and other glowing parts.
		return !Config.on(Feature.FAR_LAYERS) || !FarDetail.isFar(state, Setting.DETAIL_DISTANCE)
				|| !(feature instanceof EyesFeatureRenderer
						|| feature instanceof BreezeEyesFeatureRenderer
						|| feature instanceof SaddleFeatureRenderer
						|| feature instanceof StuckObjectsFeatureRenderer
						|| feature instanceof EmissiveFeatureRenderer);
	}
}
