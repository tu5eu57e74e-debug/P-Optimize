package com.proo.poptimize;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.util.Arrays;

/** Measures 30 seconds of play: average FPS, the slowest 1% of frames and the slowest frame. */
public final class Benchmark {
	private static final long DURATION = 30_000_000_000L;

	private static long[] frames;
	private static int count;
	private static long total;
	private static long last;

	private Benchmark() {
	}

	public static void start() {
		frames = new long[4096];
		count = 0;
		total = 0;
		last = 0;
	}

	public static boolean running() {
		return frames != null;
	}

	public static int secondsLeft() {
		return (int) Math.ceil((DURATION - total) / 1_000_000_000.0);
	}

	/** Called once per drawn frame. Time spent in menus is not counted. */
	public static void frame(MinecraftClient client) {
		if (frames == null) return;

		if (client.world == null) {
			frames = null;
			return;
		}

		if (client.currentScreen != null) {
			last = 0;
			return;
		}

		long now = System.nanoTime();

		if (last != 0) {
			if (count == frames.length) frames = Arrays.copyOf(frames, count * 2);
			frames[count++] = now - last;
			total += now - last;
		}

		last = now;

		if (total >= DURATION) finish(client);
	}

	private static void finish(MinecraftClient client) {
		long[] sorted = Arrays.copyOf(frames, count);
		Arrays.sort(sorted);
		frames = null;

		int slowCount = Math.max(1, sorted.length / 100);
		long slowTotal = 0;

		for (int i = sorted.length - slowCount; i < sorted.length; i++) {
			slowTotal += sorted[i];
		}

		long average = Math.round(sorted.length * 1_000_000_000.0 / total);
		long low = Math.round(slowCount * 1_000_000_000.0 / slowTotal);
		long worst = Math.round(1_000_000_000.0 / sorted[sorted.length - 1]);

		client.inGameHud.getChatHud().addMessage(
				Text.translatable("poptimize.benchmark.result", average, low, worst));
	}
}
