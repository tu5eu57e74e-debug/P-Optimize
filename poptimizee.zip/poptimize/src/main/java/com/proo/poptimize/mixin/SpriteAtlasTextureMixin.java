package com.proo.poptimize.mixin;

import com.proo.poptimize.Config;
import com.proo.poptimize.Feature;
import net.minecraft.client.texture.SpriteAtlasTexture;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Item 26: freezes water, lava, fire and other animated textures. */
@Mixin(SpriteAtlasTexture.class)
public class SpriteAtlasTextureMixin {
	@Unique
	private int poptimize$ticks;

	@Inject(method = "create", at = @At("HEAD"))
	private void poptimize$onReload(CallbackInfo ci) {
		this.poptimize$ticks = 0;
	}

	@Inject(method = "tickAnimatedSprites", at = @At("HEAD"), cancellable = true)
	private void poptimize$freeze(CallbackInfo ci) {
		if (!Config.on(Feature.NO_ANIMATIONS)) return;

		// Let the first ticks run so every texture gets drawn once.
		if (this.poptimize$ticks < 2) {
			this.poptimize$ticks++;
			return;
		}

		ci.cancel();
	}
}
