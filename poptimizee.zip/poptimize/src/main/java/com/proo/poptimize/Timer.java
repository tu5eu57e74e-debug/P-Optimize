package com.proo.poptimize;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

/** A stopwatch, or a countdown when a number of minutes is selected. */
public final class Timer {
	private static boolean running;
	private static boolean finished;
	private static long startedAt;
	private static long stored;

	private Timer() {
	}

	public static boolean running() {
		return running;
	}

	/** True if there is something to show on screen. */
	public static boolean active() {
		return running || stored > 0;
	}

	private static long elapsed() {
		return running ? stored + Util.getMeasuringTimeMs() - startedAt : stored;
	}

	private static long length() {
		return Config.selected(Setting.TIMER_MINUTES) * 60_000L;
	}

	public static void toggle() {
		if (running) {
			stored = elapsed();
			running = false;
		} else {
			if (finished) reset();
			startedAt = Util.getMeasuringTimeMs();
			running = true;
		}
	}

	public static void reset() {
		running = false;
		finished = false;
		stored = 0;
	}

	public static String display() {
		long length = length();
		// A countdown shows the second that is still running.
		long seconds = length == 0 ? elapsed() / 1000 : (Math.max(0, length - elapsed()) + 999) / 1000;
		long hours = seconds / 3600;
		String rest = String.format(java.util.Locale.ROOT, "%02d:%02d", seconds / 60 % 60, seconds % 60);
		return hours > 0 ? hours + ":" + rest : rest;
	}

	public static void tick(MinecraftClient client) {
		long length = length();

		if (running && length != 0 && elapsed() >= length) {
			running = false;
			finished = true;
			stored = length;
			ClickableWidget.playClickSound(client.getSoundManager());
			client.inGameHud.setOverlayMessage(Text.translatable("poptimize.timer.done"), false);
		}
	}
}
