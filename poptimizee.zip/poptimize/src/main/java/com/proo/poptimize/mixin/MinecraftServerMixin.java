package com.proo.poptimize.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.proo.poptimize.Config;
import com.proo.poptimize.Setting;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/** Longer time between autosaves in singleplayer. */
@Mixin(MinecraftServer.class)
public class MinecraftServerMixin {
	@ModifyReturnValue(method = "getAutosaveInterval", at = @At("RETURN"))
	private int poptimize$autosave(int original) {
		int minutes = Config.value(Setting.AUTOSAVE_MINUTES);
		return minutes == 0 ? original : Math.max(original, minutes * 60 * 20);
	}
}
