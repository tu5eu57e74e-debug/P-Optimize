package com.proo.poptimize;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

import java.util.Map;
import java.util.WeakHashMap;

/**
 * Item 11: hides entities that are completely behind solid blocks.
 * Results are cached and the number of checks is limited, so the check itself stays cheap.
 * Only used from the render thread.
 */
public final class Occlusion {
	private static final double MIN_DISTANCE = 12.0;
	private static final double MAX_DISTANCE = 64.0;
	private static final double STEP = 0.5;
	private static final long RECHECK_MS = 200;
	private static final long STALE_MS = 1000;
	private static final long WINDOW_MS = 50;
	private static final int CHECKS_PER_WINDOW = 24;

	private static final class Result {
		boolean hidden;
		long time;
	}

	private static final Map<Entity, Result> CACHE = new WeakHashMap<>();
	private static final BlockPos.Mutable POS = new BlockPos.Mutable();
	private static long windowStart;
	private static int checksUsed;

	private Occlusion() {
	}

	public static boolean isHidden(Entity entity, double cameraX, double cameraY, double cameraZ) {
		if (Culling.isProtected(entity) || entity.isGlowing() || entity.hasPassengers()) return false;

		World world = MinecraftClient.getInstance().world;
		if (world == null) return false;

		double distance = entity.squaredDistanceTo(cameraX, cameraY, cameraZ);
		if (distance < MIN_DISTANCE * MIN_DISTANCE || distance > MAX_DISTANCE * MAX_DISTANCE) return false;

		long now = System.nanoTime() / 1_000_000L;
		Result result = CACHE.get(entity);

		if (result != null && now - result.time < RECHECK_MS) return result.hidden;

		if (now - windowStart >= WINDOW_MS) {
			windowStart = now;
			checksUsed = 0;
		}

		if (checksUsed >= CHECKS_PER_WINDOW) {
			// No budget left: trust a recent answer, otherwise show the entity.
			return result != null && now - result.time < STALE_MS && result.hidden;
		}

		checksUsed++;

		if (result == null) {
			result = new Result();
			CACHE.put(entity, result);
		}

		result.hidden = !isVisible(world, entity.getBoundingBox().expand(0.25), cameraX, cameraY, cameraZ);
		result.time = now;
		return result.hidden;
	}

	/** Visible if the center or any corner of the box has a clear line to the camera. */
	private static boolean isVisible(World world, Box box, double x, double y, double z) {
		if (isClear(world, x, y, z,
				(box.minX + box.maxX) / 2, (box.minY + box.maxY) / 2, (box.minZ + box.maxZ) / 2)) {
			return true;
		}

		for (int corner = 0; corner < 8; corner++) {
			double targetX = (corner & 1) == 0 ? box.minX : box.maxX;
			double targetY = (corner & 2) == 0 ? box.minY : box.maxY;
			double targetZ = (corner & 4) == 0 ? box.minZ : box.maxZ;

			if (isClear(world, x, y, z, targetX, targetY, targetZ)) return true;
		}

		return false;
	}

	private static boolean isClear(World world, double x1, double y1, double z1, double x2, double y2, double z2) {
		double dx = x2 - x1;
		double dy = y2 - y1;
		double dz = z2 - z1;
		int steps = (int) (Math.sqrt(dx * dx + dy * dy + dz * dz) / STEP);

		for (int i = 1; i < steps; i++) {
			double t = (double) i / steps;
			POS.set(x1 + dx * t, y1 + dy * t, z1 + dz * t);

			if (world.getBlockState(POS).isOpaqueFullCube()) return false;
		}

		return true;
	}
}
