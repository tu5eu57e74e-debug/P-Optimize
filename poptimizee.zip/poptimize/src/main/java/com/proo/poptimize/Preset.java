package com.proo.poptimize;

/** Distances are in blocks. */
public enum Preset {
	//     mobs items frames stands names chests deco signs particles detail skin
	LOW   (96,  48,   48,    48,    32,   64,    48,  24,   200,      32,    64),
	MEDIUM(64,  32,   32,    32,    20,   40,    32,  16,   100,      24,    48),
	POTATO(40,  16,   16,    16,    10,   24,    16,  8,    40,       16,    32);

	public final int mobDistance;
	public final int itemDistance;
	public final int frameDistance;
	public final int standDistance;
	public final int nameDistance;
	public final int chestDistance;
	public final int decoDistance;
	public final int signTextDistance;
	/** New particles allowed per game tick. */
	public final int particlesPerTick;
	/** Past this distance, entities are drawn with less detail. */
	public final int detailDistance;
	/** Past this distance, capes and outer skin layers are skipped. */
	public final int skinDistance;

	Preset(int mob, int item, int frame, int stand, int name, int chest, int deco, int sign, int particles,
			int detail, int skin) {
		this.mobDistance = mob;
		this.itemDistance = item;
		this.frameDistance = frame;
		this.standDistance = stand;
		this.nameDistance = name;
		this.chestDistance = chest;
		this.decoDistance = deco;
		this.signTextDistance = sign;
		this.particlesPerTick = particles;
		this.detailDistance = detail;
		this.skinDistance = skin;
	}
}
