package com.proo.poptimize;

import net.minecraft.particle.ParticleEffect;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

/** Drops particles of some kinds. */
public final class ParticleFilter {
	private static int portals;

	private ParticleFilter() {
	}

	public static boolean allow(ParticleEffect effect) {
		boolean fireworks = Config.on(Feature.NO_FIREWORK_PARTICLES);
		boolean smoke = Config.on(Feature.NO_CAMPFIRE_SMOKE);
		boolean portal = Config.on(Feature.FEWER_PORTAL_PARTICLES);

		if (!fireworks && !smoke && !portal) return true;

		Identifier id = Registries.PARTICLE_TYPE.getId(effect.getType());
		if (id == null || !id.getNamespace().equals("minecraft")) return true;

		return switch (id.getPath()) {
			case "firework", "flash" -> !fireworks;
			case "campfire_cosy_smoke", "campfire_signal_smoke" -> !smoke;
			// One portal particle out of four is kept.
			case "portal" -> !portal || (portals++ & 3) == 0;
			default -> true;
		};
	}
}
