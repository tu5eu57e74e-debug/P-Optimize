package com.proo.poptimize;

import java.util.LinkedHashSet;
import java.util.Set;

/** Settings as one line of text, to keep or to move to another device. */
public final class Share {
	private static final String START = "POPT1;";
	private static final int MAX_LENGTH = 8000;

	private Share() {
	}

	public static String write() {
		StringBuilder on = new StringBuilder();
		StringBuilder off = new StringBuilder();

		for (Feature feature : Feature.values()) {
			StringBuilder list = Config.isChecked(feature) ? on : off;
			if (!list.isEmpty()) list.append(',');
			list.append(feature.name());
		}

		StringBuilder values = new StringBuilder();

		for (Setting setting : Setting.values()) {
			if (!values.isEmpty()) values.append(',');
			values.append(setting.name()).append(':').append(Config.selected(setting));
		}

		return START + "preset=" + Config.preset.name() + ";theme=" + Config.theme.name() + ";on=" + on
				+ ";off=" + off + ";set=" + values + ";fav=" + String.join(",", Config.favorites());
	}

	/** Reads text made by {@link #write}. Unknown names and values are skipped. */
	public static boolean read(String text) {
		if (text == null) return false;

		text = text.trim();
		if (!text.startsWith(START) || text.length() > MAX_LENGTH) return false;

		for (String part : text.substring(START.length()).split(";")) {
			int equals = part.indexOf('=');
			if (equals < 0) continue;

			String name = part.substring(0, equals);
			String value = part.substring(equals + 1);

			switch (name) {
				case "preset" -> {
					for (Preset preset : Preset.values()) {
						if (preset.name().equals(value)) Config.preset = preset;
					}
				}
				case "theme" -> {
					for (Theme theme : Theme.values()) {
						if (theme.name().equals(value)) Config.theme = theme;
					}
				}
				case "on", "off" -> {
					for (String item : value.split(",")) {
						for (Feature feature : Feature.values()) {
							if (feature.name().equals(item)) Config.set(feature, name.equals("on"));
						}
					}
				}
				case "set" -> {
					for (String item : value.split(",")) {
						readSetting(item);
					}
				}
				case "fav" -> {
					Set<String> favorites = new LinkedHashSet<>();

					for (String item : value.split(",")) {
						if (item.startsWith("feature:") || item.startsWith("setting:")) favorites.add(item);
					}

					Config.setFavorites(favorites);
				}
				default -> {
				}
			}
		}

		return true;
	}

	private static void readSetting(String item) {
		int colon = item.indexOf(':');
		if (colon < 0) return;

		String name = item.substring(0, colon);

		for (Setting setting : Setting.values()) {
			if (!setting.name().equals(name)) continue;

			try {
				int value = Integer.parseInt(item.substring(colon + 1));
				if (setting.allows(value)) Config.select(setting, value);
			} catch (NumberFormatException e) {
				POptimizeClient.LOGGER.warn("Bad imported value for {}", setting, e);
			}
		}
	}
}
