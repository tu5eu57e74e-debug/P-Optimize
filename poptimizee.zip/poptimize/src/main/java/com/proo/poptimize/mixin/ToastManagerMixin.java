package com.proo.poptimize.mixin;

import com.proo.poptimize.Config;
import com.proo.poptimize.Feature;
import net.minecraft.client.toast.AdvancementToast;
import net.minecraft.client.toast.RecipeToast;
import net.minecraft.client.toast.Toast;
import net.minecraft.client.toast.ToastManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** No advancement or recipe pop-ups. */
@Mixin(ToastManager.class)
public class ToastManagerMixin {
	@Inject(method = "add", at = @At("HEAD"), cancellable = true)
	private void poptimize$noToasts(Toast toast, CallbackInfo ci) {
		if (Config.on(Feature.NO_TOASTS) && (toast instanceof AdvancementToast || toast instanceof RecipeToast)) {
			ci.cancel();
		}
	}
}
