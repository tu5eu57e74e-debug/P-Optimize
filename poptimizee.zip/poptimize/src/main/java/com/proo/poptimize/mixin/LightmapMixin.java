package com.proo.poptimize.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.proo.poptimize.Config;
import com.proo.poptimize.Feature;
import com.proo.poptimize.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.client.render.LightmapTextureManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/** Fullbright: the light map sees a very high brightness. The saved setting is not changed. */
@Mixin(LightmapTextureManager.class)
public class LightmapMixin {
	@WrapOperation(method = "update", require = 0, at = @At(value = "INVOKE",
			target = "Lnet/minecraft/client/option/SimpleOption;getValue()Ljava/lang/Object;"))
	private Object poptimize$fullbright(SimpleOption<?> option, Operation<Object> original) {
		if (Config.on(Feature.FULLBRIGHT) && option == MinecraftClient.getInstance().options.getGamma()) {
			return (double) Config.selected(Setting.BRIGHTNESS);
		}

		return original.call(option);
	}
}
