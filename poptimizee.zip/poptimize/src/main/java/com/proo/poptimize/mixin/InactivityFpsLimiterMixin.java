package com.proo.poptimize.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.proo.poptimize.AutoModes;
import com.proo.poptimize.Config;
import com.proo.poptimize.Feature;
import com.proo.poptimize.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.InactivityFpsLimiter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/** Very low frame rate while the game is not focused or the player is away. */
@Mixin(InactivityFpsLimiter.class)
public class InactivityFpsLimiterMixin {
	@ModifyReturnValue(method = "update", at = @At("RETURN"))
	private int poptimize$background(int original) {
		int limit = original;

		if (Config.on(Feature.BACKGROUND_FPS) && !MinecraftClient.getInstance().isWindowFocused()) {
			limit = Math.min(limit, Config.selected(Setting.BACKGROUND_FPS_LIMIT));
		}

		if (AutoModes.away()) {
			limit = Math.min(limit, 10);
		}

		return limit;
	}
}
