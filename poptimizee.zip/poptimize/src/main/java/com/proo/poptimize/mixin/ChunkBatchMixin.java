package com.proo.poptimize.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.proo.poptimize.Config;
import com.proo.poptimize.Setting;
import net.minecraft.client.network.ChunkBatchSizeCalculator;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/** Asks the server for fewer chunks at a time, so loading causes smaller stutters. */
@Mixin(ChunkBatchSizeCalculator.class)
public class ChunkBatchMixin {
	@ModifyReturnValue(method = "getDesiredChunksPerTick", at = @At("RETURN"))
	private float poptimize$smoothLoading(float original) {
		int rate = Config.value(Setting.CHUNK_RATE);
		return rate == 0 ? original : Math.min(original, rate);
	}
}
