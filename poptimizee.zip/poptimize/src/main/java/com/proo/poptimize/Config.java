package com.proo.poptimize;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.EnumSet;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.atomic.AtomicIntegerArray;

public final class Config {
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("poptimize.properties");
	private static final Properties PROPERTIES = new Properties();
	/** Switches that are on. Read by other threads, so it is replaced and never edited in place. */
	private static volatile EnumSet<Feature> checked = defaults();

	/** Read by chunk builder and server threads. */
	private static final AtomicIntegerArray VALUES = new AtomicIntegerArray(Setting.values().length);
	/** Menu entries marked with a star, such as "feature:NO_CLOUDS". */
	private static final Set<String> FAVORITES = new LinkedHashSet<>();

	static {
		for (Setting setting : Setting.values()) {
			VALUES.set(setting.ordinal(), setting.defaultValue);
		}
	}

	/** Raised when an update adds video settings that still have to be applied. */
	private static final int VERSION = 3;

	public static volatile Preset preset = Preset.MEDIUM;
	/** Master switch. */
	public static volatile boolean enabled = true;
	public static volatile Theme theme = Theme.RED;
	/** True once the video settings were applied at least once. */
	public static boolean applied = false;

	private Config() {
	}

	/** Recording mode pauses every other feature for clean, good looking footage. */
	public static boolean recording() {
		return enabled && isChecked(Feature.RECORDING_MODE);
	}

	/** True if the feature should act now. */
	public static boolean on(Feature feature) {
		return enabled && !recording() && isChecked(feature);
	}

	/** Privacy: streamer mode keeps working in recording mode. */
	public static boolean streaming() {
		return enabled && isChecked(Feature.STREAMER_MODE);
	}

	/** The selected value, with "auto" replaced by the value of the preset. */
	public static int amount(Setting setting) {
		int value = selected(setting);
		return value == 0 && setting.zero == Setting.Zero.AUTO ? setting.auto(preset) : value;
	}

	public static boolean isFavorite(String key) {
		return FAVORITES.contains(key);
	}

	public static void toggleFavorite(String key) {
		if (!FAVORITES.remove(key)) FAVORITES.add(key);
	}

	public static Set<String> favorites() {
		return new LinkedHashSet<>(FAVORITES);
	}

	public static void setFavorites(Set<String> keys) {
		FAVORITES.clear();
		FAVORITES.addAll(keys);
	}

	public static void set(Feature feature, boolean on) {
		if (isChecked(feature) != on) toggle(feature);
	}

	private static EnumSet<Feature> defaults() {
		EnumSet<Feature> result = EnumSet.noneOf(Feature.class);

		for (Feature feature : Feature.values()) {
			if (feature.defaultOn) result.add(feature);
		}

		return result;
	}

	/** Saved screen position of an on-screen counter. */
	public static int number(String key, int fallback) {
		try {
			return Integer.parseInt(PROPERTIES.getProperty(key, "").trim());
		} catch (NumberFormatException e) {
			return fallback;
		}
	}

	public static void setNumber(String key, int value) {
		PROPERTIES.setProperty(key, Integer.toString(value));
	}

	/** The state of the switch itself, ignoring the master switch. */
	public static boolean isChecked(Feature feature) {
		return checked.contains(feature);
	}

	public static void toggle(Feature feature) {
		EnumSet<Feature> copy = EnumSet.copyOf(checked);
		if (!copy.remove(feature)) copy.add(feature);
		checked = copy;
	}

	/** The active value of a setting: 0 if it is off or the mod is disabled. */
	public static int value(Setting setting) {
		return enabled && !recording() ? VALUES.get(setting.ordinal()) : 0;
	}

	/** The selected value, ignoring the master switch. */
	public static int selected(Setting setting) {
		return VALUES.get(setting.ordinal());
	}

	public static void select(Setting setting, int value) {
		VALUES.set(setting.ordinal(), value);
	}

	/** The player's own video setting from before the mod changed it, or null. */
	public static String original(String key) {
		return PROPERTIES.getProperty("original." + key);
	}

	public static void setOriginal(String key, String value) {
		if (value == null) {
			PROPERTIES.remove("original." + key);
		} else {
			PROPERTIES.setProperty("original." + key, value);
		}
	}

	public static void load() {
		if (!Files.exists(FILE)) return;

		try (Reader reader = Files.newBufferedReader(FILE)) {
			PROPERTIES.load(reader);
		} catch (IOException | IllegalArgumentException e) {
			POptimizeClient.LOGGER.warn("Could not read config, using defaults", e);
			return;
		}

		try {
			preset = Preset.valueOf(PROPERTIES.getProperty("preset", "MEDIUM").trim().toUpperCase(Locale.ROOT));
		} catch (IllegalArgumentException e) {
			preset = Preset.MEDIUM;
		}

		enabled = Boolean.parseBoolean(PROPERTIES.getProperty("enabled", "true"));
		applied = Boolean.parseBoolean(PROPERTIES.getProperty("applied", "false"))
				&& Integer.toString(VERSION).equals(PROPERTIES.getProperty("version"));

		for (Setting setting : Setting.values()) {
			try {
				int value = Integer.parseInt(PROPERTIES.getProperty("setting." + setting.name(),
						Integer.toString(setting.defaultValue)).trim());
				if (setting.allows(value)) select(setting, value);
			} catch (NumberFormatException e) {
				POptimizeClient.LOGGER.warn("Bad value for {}", setting, e);
			}
		}

		EnumSet<Feature> loaded = EnumSet.noneOf(Feature.class);

		for (Feature feature : Feature.values()) {
			String fallback = Boolean.toString(feature.defaultOn);

			if (Boolean.parseBoolean(PROPERTIES.getProperty("feature." + feature.name(), fallback))) {
				loaded.add(feature);
			}
		}

		checked = loaded;

		FAVORITES.clear();

		for (String key : PROPERTIES.getProperty("favorites", "").split(",")) {
			if (!key.isBlank()) FAVORITES.add(key.trim());
		}

		try {
			theme = Theme.valueOf(PROPERTIES.getProperty("theme", "RED"));
		} catch (IllegalArgumentException e) {
			theme = Theme.RED;
		}
	}

	public static void save() {
		PROPERTIES.setProperty("preset", preset.name());
		PROPERTIES.setProperty("theme", theme.name());
		PROPERTIES.setProperty("enabled", Boolean.toString(enabled));
		PROPERTIES.setProperty("applied", Boolean.toString(applied));
		PROPERTIES.setProperty("version", Integer.toString(VERSION));

		for (Setting setting : Setting.values()) {
			PROPERTIES.setProperty("setting." + setting.name(), Integer.toString(selected(setting)));
		}

		for (Feature feature : Feature.values()) {
			PROPERTIES.setProperty("feature." + feature.name(), Boolean.toString(isChecked(feature)));
		}

		PROPERTIES.setProperty("favorites", String.join(",", FAVORITES));

		try (Writer writer = Files.newBufferedWriter(FILE)) {
			PROPERTIES.store(writer, "P-Optimize");
		} catch (IOException e) {
			POptimizeClient.LOGGER.warn("Could not save config", e);
		}
	}
}
