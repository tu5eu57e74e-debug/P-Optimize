package com.proo.poptimize.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.proo.poptimize.ChunkRange;
import com.proo.poptimize.Config;
import com.proo.poptimize.Setting;
import net.minecraft.block.AttachedStemBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.CropBlock;
import net.minecraft.block.LilyPadBlock;
import net.minecraft.block.NetherWartBlock;
import net.minecraft.block.PlantBlock;
import net.minecraft.block.StemBlock;
import net.minecraft.client.render.chunk.SectionBuilder;
import net.minecraft.util.math.ChunkSectionPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/**
 * Leaves far grass and flowers out of the chunk mesh. This only changes what is drawn.
 * WrapOperation also works together with Fabric API's redirect of the same call.
 */
@Mixin(SectionBuilder.class)
public class SectionBuilderMixin {
	@WrapOperation(method = "build", at = @At(value = "INVOKE",
			target = "Lnet/minecraft/block/BlockState;getRenderType()Lnet/minecraft/block/BlockRenderType;"))
	private BlockRenderType poptimize$hidePlants(BlockState state, Operation<BlockRenderType> original,
			@Local(argsOnly = true) ChunkSectionPos sectionPos) {
		int radius = Config.value(Setting.PLANT_CHUNKS);

		if (radius != 0) {
			Block block = state.getBlock();

			// Farm plants stay visible.
			boolean decoration = block instanceof PlantBlock
					&& !(block instanceof CropBlock)
					&& !(block instanceof StemBlock)
					&& !(block instanceof AttachedStemBlock)
					&& !(block instanceof NetherWartBlock)
					&& !(block instanceof LilyPadBlock);

			if (decoration && ChunkRange.isOutside(sectionPos.getSectionX(), sectionPos.getSectionZ(), radius)) {
				return BlockRenderType.INVISIBLE;
			}
		}

		return original.call(state);
	}
}
