package com.proo.poptimize;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

/** Far mobs and drops are updated every other tick on this computer. The server is not changed. */
public final class EntityTicking {
	private EntityTicking() {
	}

	public static boolean shouldSkip(Entity entity) {
		int limit = Config.value(Setting.ENTITY_TICK_DISTANCE);
		if (limit == 0) return false;

		boolean kind = entity instanceof ItemEntity
				|| entity instanceof ExperienceOrbEntity
				|| (entity instanceof LivingEntity && !(entity instanceof PlayerEntity));

		if (!kind || Culling.isProtected(entity) || entity.hasPassengers() || entity.hasVehicle()) return false;

		Entity camera = MinecraftClient.getInstance().getCameraEntity();

		if (camera == null || entity.squaredDistanceTo(camera.getX(), camera.getY(), camera.getZ())
				<= (double) limit * limit) {
			return false;
		}

		// The age grows on skipped ticks too, so this alternates.
		return ((entity.age + entity.getId()) & 1) == 0;
	}
}
