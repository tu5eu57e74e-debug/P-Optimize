package com.proo.poptimize;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;

/**
 * Tracks the camera's chunk for the "show within N chunks" settings.
 * A radius of 1 means the camera's chunk plus one chunk on every side.
 */
public final class ChunkRange {
	/** Chunk x in the high half and z in the low half, so both change together. */
	private static volatile long center;
	private static ClientWorld lastWorld;
	private static int lastPlantRadius;

	private ChunkRange() {
	}

	public static boolean isOutside(int chunkX, int chunkZ, int radius) {
		return isOutside(center, chunkX, chunkZ, radius);
	}

	private static boolean isOutside(long from, int chunkX, int chunkZ, int radius) {
		int x = (int) (from >> 32);
		int z = (int) from;
		return Math.abs(chunkX - x) > radius || Math.abs(chunkZ - z) > radius;
	}

	/** Rebuilds the chunks whose plants have to appear or disappear. */
	public static void tick(MinecraftClient client) {
		ClientWorld world = client.world;
		Entity camera = client.getCameraEntity();

		if (world == null || camera == null) {
			lastWorld = null;
			return;
		}

		long previous = center;
		int x = camera.getBlockPos().getX() >> 4;
		int z = camera.getBlockPos().getZ() >> 4;
		long current = ((long) x << 32) | (z & 0xFFFFFFFFL);
		int radius = Config.value(Setting.PLANT_CHUNKS);
		center = current;

		if (world != lastWorld || radius != lastPlantRadius) {
			if (radius != 0 || lastPlantRadius != 0) client.worldRenderer.reload();
		} else if (radius != 0 && current != previous) {
			rebuildChanged(world, previous, current, previous, radius);
			rebuildChanged(world, previous, current, current, radius);
		}

		lastWorld = world;
		lastPlantRadius = radius;
	}

	/** Checks the square around one center. A chunk inside both squares never changes. */
	private static void rebuildChanged(ClientWorld world, long previous, long current, long around, int radius) {
		int aroundX = (int) (around >> 32);
		int aroundZ = (int) around;
		int bottom = world.getBottomSectionCoord();
		int top = world.getTopSectionCoord();

		for (int x = aroundX - radius; x <= aroundX + radius; x++) {
			for (int z = aroundZ - radius; z <= aroundZ + radius; z++) {
				if (isOutside(previous, x, z, radius) != isOutside(current, x, z, radius)) {
					world.scheduleChunkRenders(x, bottom, z, x, top, z);
				}
			}
		}
	}
}
