package com.proo.poptimize;

import net.minecraft.block.entity.BannerBlockEntity;
import net.minecraft.block.entity.BeaconBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.CampfireBlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.DecoratedPotBlockEntity;
import net.minecraft.block.entity.EnchantingTableBlockEntity;
import net.minecraft.block.entity.EndPortalBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.block.entity.PistonBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.block.entity.SignBlockEntity;
import net.minecraft.block.entity.SkullBlockEntity;
import net.minecraft.block.entity.TrialSpawnerBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.boss.WitherEntity;
import net.minecraft.entity.boss.dragon.EnderDragonEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.decoration.DisplayEntity;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.entity.decoration.painting.PaintingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;

/** Distance culling: items 10, 13, 14, 15, 18, 19 and 20. */
public final class Culling {
	private Culling() {
	}

	/** Players and bosses are never hidden. */
	public static boolean isProtected(Entity entity) {
		return entity instanceof PlayerEntity
				|| entity instanceof EnderDragonEntity
				|| entity instanceof WitherEntity;
	}

	public static boolean isTooFar(Entity entity, double cameraX, double cameraY, double cameraZ) {
		// Other players are only hidden if the player asked for it.
		if (entity instanceof PlayerEntity) {
			if (!Config.on(Feature.CULL_PLAYERS)) return false;

			int limit = Config.amount(Setting.DIST_PLAYERS);

			return entity != MinecraftClient.getInstance().player
					&& entity != MinecraftClient.getInstance().getCameraEntity()
					&& entity.squaredDistanceTo(cameraX, cameraY, cameraZ) > (double) limit * limit;
		}

		if (isProtected(entity)) return false;

		// Display entities have their own distance. Without one they count as mobs, as before.
		int displayLimit = Config.value(Setting.DISPLAY_DISTANCE);

		if (displayLimit != 0 && entity instanceof DisplayEntity) {
			return entity.squaredDistanceTo(cameraX, cameraY, cameraZ) > (double) displayLimit * displayLimit;
		}

		Setting setting;
		Feature feature;

		if (entity instanceof ExperienceOrbEntity) {
			feature = Feature.CULL_XP;
			setting = Setting.DIST_ITEMS;
		} else if (entity instanceof PaintingEntity) {
			feature = Feature.CULL_PAINTINGS;
			setting = Setting.DIST_FRAMES;
		} else if (entity instanceof ItemEntity) {
			feature = Feature.CULL_ITEMS;
			setting = Setting.DIST_ITEMS;
		} else if (entity instanceof ItemFrameEntity) {
			feature = Feature.CULL_FRAMES;
			setting = Setting.DIST_FRAMES;
		} else if (entity instanceof ArmorStandEntity) {
			feature = Feature.CULL_STANDS;
			setting = Setting.DIST_STANDS;
		} else {
			feature = Feature.CULL_MOBS;
			setting = Setting.DIST_MOBS;
		}

		if (!Config.on(feature)) return false;

		int limit = Config.amount(setting);
		return entity.squaredDistanceTo(cameraX, cameraY, cameraZ) > (double) limit * limit;
	}

	public static boolean isTooFar(BlockEntity blockEntity) {
		// TrappedChestBlockEntity extends ChestBlockEntity.
		if (blockEntity instanceof ChestBlockEntity
				|| blockEntity instanceof EnderChestBlockEntity
				|| blockEntity instanceof ShulkerBoxBlockEntity) {
			return Config.on(Feature.CULL_CHESTS) && isBeyond(blockEntity.getPos(), Config.amount(Setting.DIST_CHESTS));
		}

		if (blockEntity instanceof SkullBlockEntity || blockEntity instanceof BannerBlockEntity) {
			return Config.on(Feature.CULL_DECORATIONS) && isBeyond(blockEntity.getPos(), Config.amount(Setting.DIST_DECORATIONS));
		}

		if (blockEntity instanceof PistonBlockEntity) {
			return Config.on(Feature.CULL_PISTONS) && isBeyond(blockEntity.getPos(), Config.amount(Setting.DIST_DECORATIONS));
		}

		if (blockEntity instanceof CampfireBlockEntity || blockEntity instanceof DecoratedPotBlockEntity) {
			return Config.on(Feature.CULL_CAMPFIRE_POTS) && isBeyond(blockEntity.getPos(), Config.amount(Setting.DIST_DECORATIONS));
		}

		// EndGatewayBlockEntity extends EndPortalBlockEntity.
		if (blockEntity instanceof EndPortalBlockEntity) {
			return Config.on(Feature.FAR_END_PORTAL)
					&& isBeyond(blockEntity.getPos(), Config.amount(Setting.DIST_DECORATIONS));
		}

		// These renderers only draw the extra part, the block itself stays.
		if (blockEntity instanceof EnchantingTableBlockEntity) {
			return Config.on(Feature.CULL_ENCHANT_BOOK) && isBeyond(blockEntity.getPos(), Config.amount(Setting.DIST_SIGN_TEXT));
		}

		if (blockEntity instanceof MobSpawnerBlockEntity || blockEntity instanceof TrialSpawnerBlockEntity) {
			return Config.on(Feature.NO_SPAWNER_MOB);
		}

		if (blockEntity instanceof BeaconBlockEntity) {
			return Config.on(Feature.NO_BEACON_BEAM);
		}

		// HangingSignBlockEntity extends SignBlockEntity.
		if (blockEntity instanceof SignBlockEntity) {
			int chunks = Config.value(Setting.SIGN_CHUNKS);
			BlockPos pos = blockEntity.getPos();
			return chunks != 0 && ChunkRange.isOutside(pos.getX() >> 4, pos.getZ() >> 4, chunks);
		}

		return false;
	}

	public static boolean isBeyond(BlockPos pos, int limit) {
		Entity camera = MinecraftClient.getInstance().getCameraEntity();
		if (camera == null) return false;

		double distance = camera.squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
		return distance > (double) limit * limit;
	}
}
