package com.proo.poptimize;

import com.proo.poptimize.Feature.Category;

import java.util.Locale;

/** Settings chosen with a slider. */
public enum Setting {
	RENDER_DISTANCE(Category.VIDEO, null, Unit.CHUNKS, Zero.OFF, 0, 0, 2, 4, 6, 8, 10, 12),
	SIMULATION_DISTANCE(Category.VIDEO, null, Unit.CHUNKS, Zero.OFF, 0, 0, 3, 4),
	CHUNK_RATE(Category.VIDEO, null, Unit.NUMBER, Zero.OFF, 0, 0, 2, 5, 10),

	DIST_MOBS(Category.ENTITIES, Feature.CULL_MOBS, Unit.BLOCKS, Zero.AUTO, 0, 0, 16, 32, 48, 64, 96, 128),
	DIST_PLAYERS(Category.ENTITIES, Feature.CULL_PLAYERS, Unit.BLOCKS, Zero.AUTO, 0, 0, 32, 48, 64, 96, 128),
	DIST_NAMES(Category.ENTITIES, Feature.CULL_NAMES, Unit.BLOCKS, Zero.AUTO, 0, 0, 8, 16, 24, 32, 48, 64),
	DIST_EQUIPMENT(Category.ENTITIES, Feature.CULL_EQUIPMENT, Unit.BLOCKS, Zero.AUTO, 0, 0, 8, 16, 24, 32, 48, 64),
	DIST_ITEMS(Category.ENTITIES, Feature.CULL_ITEMS, Unit.BLOCKS, Zero.AUTO, 0, 0, 8, 16, 32, 48, 64, 96),
	DIST_FRAMES(Category.ENTITIES, Feature.CULL_FRAMES, Unit.BLOCKS, Zero.AUTO, 0, 0, 8, 16, 32, 48, 64, 96),
	DIST_STANDS(Category.ENTITIES, Feature.CULL_STANDS, Unit.BLOCKS, Zero.AUTO, 0, 0, 8, 16, 32, 48, 64, 96),
	DETAIL_DISTANCE(Category.ENTITIES, Feature.FAR_ANIMATION, Unit.BLOCKS, Zero.AUTO, 0, 0, 12, 16, 24, 32, 48, 64),
	SKIN_DISTANCE(Category.ENTITIES, Feature.FAR_SKIN, Unit.BLOCKS, Zero.AUTO, 0, 0, 32, 48, 64, 96),
	ENTITY_TICK_DISTANCE(Category.ENTITIES, null, Unit.BLOCKS, Zero.OFF, 0, 0, 16, 32, 48),
	MOB_LIMIT(Category.ENTITIES, null, Unit.NUMBER, Zero.OFF, 0, 0, 20, 40, 80),
	XP_LIMIT(Category.ENTITIES, null, Unit.NUMBER, Zero.OFF, 0, 0, 10, 25, 50),
	TNT_LIMIT(Category.ENTITIES, null, Unit.NUMBER, Zero.OFF, 0, 0, 16, 32, 64),
	DISPLAY_DISTANCE(Category.ENTITIES, null, Unit.BLOCKS, Zero.OFF, 0, 0, 16, 32, 64),
	STACK_LIMIT(Category.ENTITIES, null, Unit.NUMBER, Zero.OFF, 0, 0, 3, 6, 12),
	DROP_LIMIT(Category.ENTITIES, null, Unit.NUMBER, Zero.OFF, 0, 0, 16, 32, 64),

	DIST_CHESTS(Category.BLOCKS, Feature.CULL_CHESTS, Unit.BLOCKS, Zero.AUTO, 0, 0, 16, 32, 48, 64, 96),
	DIST_DECORATIONS(Category.BLOCKS, Feature.CULL_DECORATIONS, Unit.BLOCKS, Zero.AUTO, 0, 0, 8, 16, 32, 48, 64),
	DIST_SIGN_TEXT(Category.BLOCKS, Feature.CULL_SIGN_TEXT, Unit.BLOCKS, Zero.AUTO, 0, 0, 8, 16, 24, 32, 48),
	BLOCK_ENTITY_LIMIT(Category.BLOCKS, null, Unit.NUMBER, Zero.OFF, 0, 0, 32, 64, 128),
	PLANT_CHUNKS(Category.BLOCKS, null, Unit.CHUNKS, Zero.OFF, 0, 0, 1, 2),
	SIGN_CHUNKS(Category.BLOCKS, null, Unit.CHUNKS, Zero.OFF, 0, 0, 1, 2),

	PARTICLE_LIMIT(Category.EFFECTS, Feature.LIMIT_PARTICLES, Unit.PER_TICK, Zero.AUTO, 0, 0, 20, 50, 100, 200, 400),
	SAME_SOUND_LIMIT(Category.EFFECTS, Feature.LIMIT_SOUNDS, Unit.NUMBER, Zero.NONE, 3, 1, 2, 3, 5),
	SOUND_LIMIT(Category.EFFECTS, Feature.LIMIT_SOUNDS, Unit.PER_SECOND, Zero.OFF, 0, 0, 10, 20, 40),

	BACKGROUND_FPS_LIMIT(Category.SMART, Feature.BACKGROUND_FPS, Unit.FPS, Zero.NONE, 10, 5, 10, 20, 30),
	UNDERGROUND_DISTANCE(Category.SMART, null, Unit.CHUNKS, Zero.OFF, 0, 0, 2, 4, 6),
	UNDERGROUND_Y(Category.SMART, null, Unit.HEIGHT, Zero.NONE, 60, 20, 40, 60),
	AFK_MINUTES(Category.SMART, null, Unit.MINUTES, Zero.OFF, 0, 0, 2, 5, 10),
	AUTOSAVE_MINUTES(Category.SMART, null, Unit.MINUTES, Zero.OFF, 0, 0, 10, 15),

	BRIGHTNESS(Category.TOOLS, Feature.FULLBRIGHT, Unit.NUMBER, Zero.NONE, 15, 3, 6, 10, 15),
	ZOOM_LEVEL(Category.TOOLS, Feature.ZOOM_TOGGLE, Unit.TIMES, Zero.NONE, 4, 2, 3, 4, 6, 8),
	TIMER_MINUTES(Category.TOOLS, Feature.TIMER, Unit.MINUTES, Zero.STOPWATCH, 0, 0, 1, 3, 5, 10, 15);

	/** What the choice 0 stands for. */
	public enum Zero {
		/** The feature does nothing. */
		OFF,
		/** The value of the selected preset. */
		AUTO,
		/** The timer counts up. */
		STOPWATCH,
		/** There is no choice 0. */
		NONE
	}

	public enum Unit {
		NUMBER, CHUNKS, BLOCKS, PER_TICK, PER_SECOND, MINUTES, TIMES, FPS, HEIGHT
	}

	public final Category category;
	/** The menu lists this setting right after this feature. May be null. */
	public final Feature parent;
	public final Unit unit;
	public final Zero zero;
	public final int defaultValue;
	private final int[] choices;

	Setting(Category category, Feature parent, Unit unit, Zero zero, int defaultValue, int... choices) {
		this.category = category;
		this.parent = parent;
		this.unit = unit;
		this.zero = zero;
		this.defaultValue = defaultValue;
		this.choices = choices;
	}

	public int[] choices() {
		return this.choices.clone();
	}

	public boolean allows(int value) {
		for (int choice : this.choices) {
			if (choice == value) return true;
		}

		return false;
	}

	/** The value "auto" stands for. Only used by settings whose zero is AUTO. */
	public int auto(Preset preset) {
		return switch (this) {
			case DIST_MOBS, DIST_PLAYERS -> preset.mobDistance;
			case DIST_NAMES, DIST_EQUIPMENT -> preset.nameDistance;
			case DIST_ITEMS -> preset.itemDistance;
			case DIST_FRAMES -> preset.frameDistance;
			case DIST_STANDS -> preset.standDistance;
			case DETAIL_DISTANCE -> preset.detailDistance;
			case SKIN_DISTANCE -> preset.skinDistance;
			case DIST_CHESTS -> preset.chestDistance;
			case DIST_DECORATIONS -> preset.decoDistance;
			case DIST_SIGN_TEXT -> preset.signTextDistance;
			case PARTICLE_LIMIT -> preset.particlesPerTick;
			default -> 0;
		};
	}

	public String translationKey() {
		return "poptimize.setting." + name().toLowerCase(Locale.ROOT);
	}
}
