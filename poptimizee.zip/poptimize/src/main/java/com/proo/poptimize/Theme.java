package com.proo.poptimize;

/** Menu colors. */
public enum Theme {
	RED(0xFFC80000, 0xFFE33336, 0xFFFF6666),
	BLUE(0xFF0B4FB3, 0xFF2478E5, 0xFF63B3FF),
	GREEN(0xFF0B7A3B, 0xFF1FA855, 0xFF5FE093),
	PURPLE(0xFF5A18A8, 0xFF8438DB, 0xFFC084FF),
	ORANGE(0xFFB84E00, 0xFFE87412, 0xFFFFAE55);

	public final int dark;
	public final int main;
	public final int light;

	Theme(int dark, int main, int light) {
		this.dark = dark;
		this.main = main;
		this.light = light;
	}
}
