package com.proo.poptimize;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class Hud {
	public static final int HEIGHT = 13;

	private Hud() {
	}

	public static void register() {
		// Streamer mode hides the chat. Opening the chat screen still shows it.
		HudElementRegistry.replaceElement(VanillaHudElements.CHAT, original -> (context, tickCounter) -> {
			if (!Config.streaming()) original.render(context, tickCounter);
		});

		HudElementRegistry.addLast(Identifier.of("poptimize", "hud"), (context, tickCounter) -> {
			MinecraftClient client = MinecraftClient.getInstance();
			Benchmark.frame(client);

			if (client.options.hudHidden || client.getDebugHud().shouldShowDebugHud()) return;
			// The editor draws the counters itself.
			if (client.currentScreen instanceof HudEditorScreen) return;

			for (HudItem item : HudItem.values()) {
				if (shown(item)) draw(context, client, item);
			}

			if (Benchmark.running()) {
				Text text = Text.translatable("poptimize.benchmark.running", Benchmark.secondsLeft());
				int x = (context.getScaledWindowWidth() - width(client, text)) / 2;
				box(context, client, text, x, 4);
			}
		});
	}

	private static boolean shown(HudItem item) {
		if (!Config.on(item.feature)) return false;
		if (item == HudItem.COORDINATES) return !Config.streaming();
		// The timer only appears after it was started.
		return item != HudItem.TIMER || Timer.active();
	}

	public static Text text(MinecraftClient client, HudItem item) {
		if (item == HudItem.FPS) return Text.literal(client.getCurrentFps() + " FPS");
		if (item == HudItem.TIMER) return Text.translatable("poptimize.timer.label", Timer.display());

		// The editor also draws this counter, so streamer mode has to hide the numbers here.
		if (Config.streaming()) return Text.literal("XYZ: ---");

		Entity camera = client.getCameraEntity();
		if (camera == null) return Text.literal("XYZ: 0 64 0  N");

		// Yaw 0 looks south and grows clockwise.
		String[] directions = {"S", "W", "N", "E"};
		String direction = directions[Math.floorMod(Math.round(camera.getYaw() / 90.0F), 4)];

		return Text.literal("XYZ: " + camera.getBlockPos().getX() + " " + camera.getBlockPos().getY() + " "
				+ camera.getBlockPos().getZ() + "  " + direction);
	}

	public static int width(MinecraftClient client, Text text) {
		return client.textRenderer.getWidth(text) + 10;
	}

	/** Draws one counter, kept inside the screen. */
	public static void draw(DrawContext context, MinecraftClient client, HudItem item) {
		Text text = text(client, item);
		int x = Math.max(0, Math.min(item.x(), context.getScaledWindowWidth() - width(client, text)));
		int y = Math.max(0, Math.min(item.y(), context.getScaledWindowHeight() - HEIGHT));
		box(context, client, text, x, y);
	}

	private static void box(DrawContext context, MinecraftClient client, Text text, int x, int y) {
		context.fill(x, y, x + 2, y + HEIGHT, Config.theme.main);
		context.fill(x + 2, y, x + width(client, text), y + HEIGHT, 0x90000000);
		context.drawTextWithShadow(client.textRenderer, text, x + 6, y + 3, 0xFFFFFFFF);
	}
}
