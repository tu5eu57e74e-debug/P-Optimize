package com.proo.poptimize.mixin;

import com.proo.poptimize.Config;
import com.proo.poptimize.Feature;
import net.minecraft.client.render.WeatherRendering;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Item 24: no rain or snow on screen. */
@Mixin(WeatherRendering.class)
public class WeatherRenderingMixin {
	@Inject(method = "renderPrecipitation", at = @At("HEAD"), cancellable = true)
	private void poptimize$noWeather(CallbackInfo ci) {
		if (Config.on(Feature.NO_WEATHER)) {
			ci.cancel();
		}
	}

	@Inject(method = "addParticlesAndSound", at = @At("HEAD"), cancellable = true)
	private void poptimize$noSplash(CallbackInfo ci) {
		if (Config.on(Feature.NO_RAIN_SPLASH)) {
			ci.cancel();
		}
	}
}
