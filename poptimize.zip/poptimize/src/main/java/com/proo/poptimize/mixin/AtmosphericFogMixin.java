package com.proo.poptimize.mixin;

import com.proo.poptimize.FogControl;
import net.minecraft.client.render.fog.AtmosphericFogModifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Remembers that the normal open air fog is in use. */
@Mixin(AtmosphericFogModifier.class)
public class AtmosphericFogMixin {
	@Inject(method = "applyStartEndModifier", at = @At("TAIL"), require = 0)
	private void poptimize$openAir(CallbackInfo ci) {
		FogControl.openAir();
	}
}
