package com.proo.poptimize;

/** Distances are in blocks. */
public enum Preset {
	//     mobs items frames stands names chests deco signs particles maxFps
	LOW   (96,  48,   48,    48,    32,   64,    48,  24,   200,      60),
	MEDIUM(64,  32,   32,    32,    20,   40,    32,  16,   100,      40),
	POTATO(40,  16,   16,    16,    10,   24,    16,  8,    40,       30);

	public final int mobDistance;
	public final int itemDistance;
	public final int frameDistance;
	public final int standDistance;
	public final int nameDistance;
	public final int chestDistance;
	public final int decoDistance;
	public final int signTextDistance;
	/** New particles allowed per game tick. */
	public final int particlesPerTick;
	public final int maxFps;

	Preset(int mob, int item, int frame, int stand, int name, int chest, int deco, int sign, int particles, int maxFps) {
		this.mobDistance = mob;
		this.itemDistance = item;
		this.frameDistance = frame;
		this.standDistance = stand;
		this.nameDistance = name;
		this.chestDistance = chest;
		this.decoDistance = deco;
		this.signTextDistance = sign;
		this.particlesPerTick = particles;
		this.maxFps = maxFps;
	}
}
