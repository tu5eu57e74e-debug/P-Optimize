package com.proo.poptimize;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Draws only some of the entities piled in one block, and only the nearest dropped items. */
public final class CrowdLimit {
	private record Key(long position, EntityType<?> type) {
	}

	private static final Set<Entity> HIDDEN = Collections.newSetFromMap(new IdentityHashMap<>());
	private static int ticks;

	private CrowdLimit() {
	}

	public static boolean isHidden(Entity entity) {
		return !HIDDEN.isEmpty() && HIDDEN.contains(entity);
	}

	public static void tick(MinecraftClient client) {
		if (++ticks < 5) return;
		ticks = 0;
		HIDDEN.clear();

		int stackLimit = Config.value(Setting.STACK_LIMIT);
		int dropLimit = Config.value(Setting.DROP_LIMIT);

		if (client.world == null || client.player == null || (stackLimit == 0 && dropLimit == 0)) return;

		Map<Key, Integer> piles = new HashMap<>();
		List<Entity> drops = new ArrayList<>();

		for (Entity entity : client.world.getEntities()) {
			boolean pileable = entity instanceof ItemEntity
					|| entity instanceof ExperienceOrbEntity
					|| (entity instanceof LivingEntity && !(entity instanceof PlayerEntity));

			// Named, glowing and ridden entities always stay visible.
			if (!pileable || entity.hasCustomName() || entity.isGlowing() || entity.hasPassengers()) continue;

			if (stackLimit != 0) {
				Key key = new Key(entity.getBlockPos().asLong(), entity.getType());

				if (piles.merge(key, 1, Integer::sum) > stackLimit) {
					HIDDEN.add(entity);
					continue;
				}
			}

			if (dropLimit != 0 && entity instanceof ItemEntity) drops.add(entity);
		}

		if (dropLimit != 0 && drops.size() > dropLimit) {
			Entity player = client.player;
			drops.sort(Comparator.comparingDouble(
					(Entity drop) -> drop.squaredDistanceTo(player.getX(), player.getY(), player.getZ())));
			HIDDEN.addAll(drops.subList(dropLimit, drops.size()));
		}
	}
}
