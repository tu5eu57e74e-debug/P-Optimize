package com.proo.poptimize;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/** Shown in the game's Controls screen next to the vanilla keys. */
public final class Keys {
	private static KeyBinding menu;
	private static KeyBinding zoom;

	private Keys() {
	}

	public static void register() {
		KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("poptimize", "main"));

		menu = KeyBindingHelper.registerKeyBinding(
				new KeyBinding("key.poptimize.menu", GLFW.GLFW_KEY_O, category));
		zoom = KeyBindingHelper.registerKeyBinding(
				new KeyBinding("key.poptimize.zoom", GLFW.GLFW_KEY_Z, category));
	}

	public static void tick(MinecraftClient client) {
		while (menu.wasPressed()) {
			if (client.currentScreen == null) client.setScreen(new MenuScreen(null));
		}

		boolean pressed = false;

		while (zoom.wasPressed()) {
			pressed = !pressed;
		}

		if (Config.isChecked(Feature.ZOOM_TOGGLE)) {
			// One tap zooms in, the next tap zooms out. Easy on touch screens.
			if (pressed) Zoom.active = !Zoom.active;
		} else {
			Zoom.active = zoom.isPressed();
		}

		if (client.world == null) Zoom.active = false;
	}
}
