package com.proo.poptimize;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.chunk.ChunkBuilder;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;

import java.util.List;

/**
 * Takes chunk sections that are too far away out of the list of sections to draw. They are
 * then neither drawn nor built. The world itself is not touched.
 */
public final class ChunkCull {
	private ChunkCull() {
	}

	public static void filter(List<ChunkBuilder.BuiltChunk> sections) {
		int vertical = Config.value(Setting.VERTICAL_DISTANCE);
		int radius = SmartDistance.radius();
		if (vertical == 0 && radius == 0) return;

		Entity camera = MinecraftClient.getInstance().getCameraEntity();
		if (camera == null) return;

		BlockPos center = camera.getBlockPos();
		int centerX = center.getX() >> 4;
		int centerY = center.getY() >> 4;
		int centerZ = center.getZ() >> 4;
		int size = sections.size();
		int kept = 0;

		// Compacted in one pass; removing one by one would be slow with thousands of sections.
		for (int i = 0; i < size; i++) {
			ChunkBuilder.BuiltChunk section = sections.get(i);
			BlockPos origin = section.getOrigin();

			if (vertical != 0 && Math.abs((origin.getY() >> 4) - centerY) > vertical) continue;

			if (radius != 0) {
				int x = (origin.getX() >> 4) - centerX;
				int z = (origin.getZ() >> 4) - centerZ;
				// Half a chunk of slack keeps the edge round without gaps.
				if (x * x + z * z > radius * radius + radius) continue;
			}

			sections.set(kept++, section);
		}

		if (kept < size) sections.subList(kept, size).clear();
	}
}
