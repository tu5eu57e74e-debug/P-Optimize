package com.proo.poptimize;

import java.util.Locale;

/** Settings with several choices. The value 0 means the feature is off. */
public enum Setting {
	RENDER_DISTANCE(0, 2, 4, 6, 8),
	SIMULATION_DISTANCE(0, 3, 4),
	PLANT_CHUNKS(0, 1, 2),
	SIGN_CHUNKS(0, 1, 2);

	private final int[] choices;

	Setting(int... choices) {
		this.choices = choices;
	}

	public int[] choices() {
		return this.choices.clone();
	}

	public boolean allows(int value) {
		for (int choice : this.choices) {
			if (choice == value) return true;
		}

		return false;
	}

	public String translationKey() {
		return "poptimize.setting." + name().toLowerCase(Locale.ROOT);
	}
}
