package com.proo.poptimize.mixin;

import com.proo.poptimize.Config;
import com.proo.poptimize.Feature;
import net.minecraft.client.render.SkyRendering;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Leaves out parts of the sky. */
@Mixin(SkyRendering.class)
public class SkyRenderingMixin {
	@Inject(method = {"renderTopSky", "renderSkyDark", "renderGlowingSky", "renderEndSky"},
			at = @At("HEAD"), cancellable = true, require = 0)
	private void poptimize$noSky(CallbackInfo ci) {
		if (Config.on(Feature.NO_SKY)) ci.cancel();
	}

	@Inject(method = "renderStars", at = @At("HEAD"), cancellable = true, require = 0)
	private void poptimize$noStars(CallbackInfo ci) {
		if (Config.on(Feature.NO_STARS)) ci.cancel();
	}

	@Inject(method = "renderSun", at = @At("HEAD"), cancellable = true, require = 0)
	private void poptimize$noSun(CallbackInfo ci) {
		if (Config.on(Feature.NO_SUN)) ci.cancel();
	}

	@Inject(method = "renderMoon", at = @At("HEAD"), cancellable = true, require = 0)
	private void poptimize$noMoon(CallbackInfo ci) {
		if (Config.on(Feature.NO_MOON)) ci.cancel();
	}
}
