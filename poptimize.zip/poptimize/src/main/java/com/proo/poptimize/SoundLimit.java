package com.proo.poptimize;

import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;

import java.util.HashMap;
import java.util.Map;

/** Lets only a few copies of the same mob or block sound start close together. */
public final class SoundLimit {
	private static final long WINDOW_MS = 250;
	private static final int PER_WINDOW = 3;

	private static final Map<SoundEvent, Integer> COUNTS = new HashMap<>();
	private static long windowStart;

	private SoundLimit() {
	}

	public static synchronized boolean allow(SoundEvent event, SoundCategory category) {
		// Music, records, players and the interface are never limited.
		if (category != SoundCategory.HOSTILE && category != SoundCategory.NEUTRAL
				&& category != SoundCategory.BLOCKS) {
			return true;
		}

		long now = System.nanoTime() / 1_000_000L;

		if (now - windowStart >= WINDOW_MS) {
			windowStart = now;
			COUNTS.clear();
		}

		return COUNTS.merge(event, 1, Integer::sum) <= PER_WINDOW;
	}
}
