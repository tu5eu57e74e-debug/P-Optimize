package com.proo.poptimize.mixin;

import com.proo.poptimize.Config;
import com.proo.poptimize.Feature;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** No fire covering the screen. */
@Mixin(InGameOverlayRenderer.class)
public class InGameOverlayMixin {
	@Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true)
	private static void poptimize$noFire(CallbackInfo ci) {
		if (Config.on(Feature.NO_FIRE)) {
			ci.cancel();
		}
	}
}
