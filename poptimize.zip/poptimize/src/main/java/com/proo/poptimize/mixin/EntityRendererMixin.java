package com.proo.poptimize.mixin;

import com.proo.poptimize.Config;
import com.proo.poptimize.Feature;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Item 16: hides far name tags. */
@Mixin(EntityRenderer.class)
public class EntityRendererMixin {
	@Inject(
			method = "updateRenderState(Lnet/minecraft/entity/Entity;Lnet/minecraft/client/render/entity/state/EntityRenderState;F)V",
			at = @At("RETURN"))
	private void poptimize$hideNames(Entity entity, EntityRenderState state, float tickProgress, CallbackInfo ci) {
		if (!Config.on(Feature.CULL_NAMES)) return;

		double limit = Config.preset.nameDistance;

		if (state.squaredDistanceToCamera > limit * limit) {
			state.displayName = null;
		}
	}
}
