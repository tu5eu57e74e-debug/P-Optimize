package com.proo.poptimize.mixin;

import com.proo.poptimize.Config;
import com.proo.poptimize.Feature;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Hides far name tags and the fire on burning entities. */
@Mixin(EntityRenderer.class)
public class EntityRendererMixin {
	@Inject(
			method = "updateRenderState(Lnet/minecraft/entity/Entity;Lnet/minecraft/client/render/entity/state/EntityRenderState;F)V",
			at = @At("RETURN"))
	private void poptimize$hideNames(Entity entity, EntityRenderState state, float tickProgress, CallbackInfo ci) {
		if (Config.on(Feature.NO_FIRE)) {
			state.onFire = false;
		}

		Feature feature = entity instanceof PlayerEntity ? Feature.CULL_PLAYER_NAMES : Feature.CULL_NAMES;
		double limit = Config.preset.nameDistance;

		if (Config.on(feature) && state.squaredDistanceToCamera > limit * limit) {
			state.displayName = null;
		}
	}
}
