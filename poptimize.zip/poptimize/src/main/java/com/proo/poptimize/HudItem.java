package com.proo.poptimize;

/** On-screen counters that can be moved in the HUD editor. */
public enum HudItem {
	FPS(Feature.FPS_COUNTER, 4, 4),
	COORDINATES(Feature.COORDINATES, 4, 20);

	public final Feature feature;
	private final int defaultX;
	private final int defaultY;

	HudItem(Feature feature, int defaultX, int defaultY) {
		this.feature = feature;
		this.defaultX = defaultX;
		this.defaultY = defaultY;
	}

	public int x() {
		return Config.number("hud." + name() + ".x", this.defaultX);
	}

	public int y() {
		return Config.number("hud." + name() + ".y", this.defaultY);
	}

	public void move(int x, int y) {
		Config.setNumber("hud." + name() + ".x", x);
		Config.setNumber("hud." + name() + ".y", y);
	}

	public void reset() {
		move(this.defaultX, this.defaultY);
	}
}
