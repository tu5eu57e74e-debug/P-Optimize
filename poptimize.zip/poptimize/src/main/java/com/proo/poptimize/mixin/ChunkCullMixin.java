package com.proo.poptimize.mixin;

import com.proo.poptimize.ChunkCull;
import net.minecraft.client.render.ChunkRenderingDataPreparer;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.chunk.ChunkBuilder;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

/** Applies the vertical and smart draw distance to the visible chunk sections. */
@Mixin(ChunkRenderingDataPreparer.class)
public class ChunkCullMixin {
	@Inject(method = "collectChunks", at = @At("TAIL"), require = 0)
	private void poptimize$limit(Frustum frustum, List<ChunkBuilder.BuiltChunk> sections,
			List<ChunkBuilder.BuiltChunk> nearby, CallbackInfo ci) {
		ChunkCull.filter(sections);
	}
}
