package com.proo.poptimize;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.EnumSet;
import java.util.Locale;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicIntegerArray;

public final class Config {
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("poptimize.properties");
	private static final Properties PROPERTIES = new Properties();
	private static final EnumSet<Feature> DISABLED = EnumSet.noneOf(Feature.class);

	/** Read by chunk builder and server threads. */
	private static final AtomicIntegerArray VALUES = new AtomicIntegerArray(Setting.values().length);
	/** Raised when an update adds video settings that still have to be applied. */
	private static final int VERSION = 2;

	public static volatile Preset preset = Preset.MEDIUM;
	/** Master switch. */
	public static volatile boolean enabled = true;
	/** True once the video settings were applied at least once. */
	public static boolean applied = false;

	private Config() {
	}

	public static boolean on(Feature feature) {
		return enabled && !DISABLED.contains(feature);
	}

	/** The state of the switch itself, ignoring the master switch. */
	public static boolean isChecked(Feature feature) {
		return !DISABLED.contains(feature);
	}

	public static void toggle(Feature feature) {
		if (!DISABLED.remove(feature)) DISABLED.add(feature);
	}

	/** The active value of a setting: 0 if it is off or the mod is disabled. */
	public static int value(Setting setting) {
		return enabled ? VALUES.get(setting.ordinal()) : 0;
	}

	/** The selected value, ignoring the master switch. */
	public static int selected(Setting setting) {
		return VALUES.get(setting.ordinal());
	}

	public static void select(Setting setting, int value) {
		VALUES.set(setting.ordinal(), value);
	}

	/** The player's own video setting from before the mod changed it, or null. */
	public static String original(String key) {
		return PROPERTIES.getProperty("original." + key);
	}

	public static void setOriginal(String key, String value) {
		if (value == null) {
			PROPERTIES.remove("original." + key);
		} else {
			PROPERTIES.setProperty("original." + key, value);
		}
	}

	public static void load() {
		if (!Files.exists(FILE)) return;

		try (Reader reader = Files.newBufferedReader(FILE)) {
			PROPERTIES.load(reader);
		} catch (IOException | IllegalArgumentException e) {
			POptimizeClient.LOGGER.warn("Could not read config, using defaults", e);
			return;
		}

		try {
			preset = Preset.valueOf(PROPERTIES.getProperty("preset", "MEDIUM").trim().toUpperCase(Locale.ROOT));
		} catch (IllegalArgumentException e) {
			preset = Preset.MEDIUM;
		}

		enabled = Boolean.parseBoolean(PROPERTIES.getProperty("enabled", "true"));
		applied = Boolean.parseBoolean(PROPERTIES.getProperty("applied", "false"))
				&& Integer.toString(VERSION).equals(PROPERTIES.getProperty("version"));

		for (Setting setting : Setting.values()) {
			try {
				int value = Integer.parseInt(PROPERTIES.getProperty("setting." + setting.name(), "0").trim());
				if (setting.allows(value)) select(setting, value);
			} catch (NumberFormatException e) {
				POptimizeClient.LOGGER.warn("Bad value for {}", setting, e);
			}
		}

		for (Feature feature : Feature.values()) {
			if (!Boolean.parseBoolean(PROPERTIES.getProperty("feature." + feature.name(), "true"))) {
				DISABLED.add(feature);
			}
		}
	}

	public static void save() {
		PROPERTIES.setProperty("preset", preset.name());
		PROPERTIES.setProperty("enabled", Boolean.toString(enabled));
		PROPERTIES.setProperty("applied", Boolean.toString(applied));
		PROPERTIES.setProperty("version", Integer.toString(VERSION));

		for (Setting setting : Setting.values()) {
			PROPERTIES.setProperty("setting." + setting.name(), Integer.toString(selected(setting)));
		}

		for (Feature feature : Feature.values()) {
			PROPERTIES.setProperty("feature." + feature.name(), Boolean.toString(isChecked(feature)));
		}

		try (Writer writer = Files.newBufferedWriter(FILE)) {
			PROPERTIES.store(writer, "P-Optimize");
		} catch (IOException e) {
			POptimizeClient.LOGGER.warn("Could not save config", e);
		}
	}
}
