package com.proo.poptimize;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.EnumSet;
import java.util.Locale;
import java.util.Properties;

public final class Config {
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("poptimize.properties");
	private static final Properties PROPERTIES = new Properties();
	private static final EnumSet<Feature> DISABLED = EnumSet.noneOf(Feature.class);

	public static Preset preset = Preset.MEDIUM;
	/** Master switch. */
	public static boolean enabled = true;
	/** True once the video settings were applied at least once. */
	public static boolean applied = false;

	private Config() {
	}

	public static boolean on(Feature feature) {
		return enabled && !DISABLED.contains(feature);
	}

	/** The state of the switch itself, ignoring the master switch. */
	public static boolean isChecked(Feature feature) {
		return !DISABLED.contains(feature);
	}

	public static void toggle(Feature feature) {
		if (!DISABLED.remove(feature)) DISABLED.add(feature);
	}

	/** The player's own video setting from before the mod changed it, or null. */
	public static String original(Feature feature) {
		return PROPERTIES.getProperty("original." + feature.name());
	}

	public static void setOriginal(Feature feature, String value) {
		if (value == null) {
			PROPERTIES.remove("original." + feature.name());
		} else {
			PROPERTIES.setProperty("original." + feature.name(), value);
		}
	}

	public static void load() {
		if (!Files.exists(FILE)) return;

		try (Reader reader = Files.newBufferedReader(FILE)) {
			PROPERTIES.load(reader);
		} catch (IOException | IllegalArgumentException e) {
			POptimizeClient.LOGGER.warn("Could not read config, using defaults", e);
			return;
		}

		try {
			preset = Preset.valueOf(PROPERTIES.getProperty("preset", "MEDIUM").trim().toUpperCase(Locale.ROOT));
		} catch (IllegalArgumentException e) {
			preset = Preset.MEDIUM;
		}

		enabled = Boolean.parseBoolean(PROPERTIES.getProperty("enabled", "true"));
		applied = Boolean.parseBoolean(PROPERTIES.getProperty("applied", "false"));

		for (Feature feature : Feature.values()) {
			if (!Boolean.parseBoolean(PROPERTIES.getProperty("feature." + feature.name(), "true"))) {
				DISABLED.add(feature);
			}
		}
	}

	public static void save() {
		PROPERTIES.setProperty("preset", preset.name());
		PROPERTIES.setProperty("enabled", Boolean.toString(enabled));
		PROPERTIES.setProperty("applied", Boolean.toString(applied));

		for (Feature feature : Feature.values()) {
			PROPERTIES.setProperty("feature." + feature.name(), Boolean.toString(isChecked(feature)));
		}

		try (Writer writer = Files.newBufferedWriter(FILE)) {
			PROPERTIES.store(writer, "P-Optimize");
		} catch (IOException e) {
			POptimizeClient.LOGGER.warn("Could not save config", e);
		}
	}
}
