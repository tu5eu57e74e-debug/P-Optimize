package com.proo.poptimize;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class FpsCounter {
	private FpsCounter() {
	}

	public static void register() {
		HudElementRegistry.addLast(Identifier.of("poptimize", "fps"), (context, tickCounter) -> {
			if (!Config.on(Feature.FPS_COUNTER)) return;

			MinecraftClient client = MinecraftClient.getInstance();
			if (client.options.hudHidden || client.getDebugHud().shouldShowDebugHud()) return;

			Text text = Text.literal(client.getCurrentFps() + " FPS");
			int width = client.textRenderer.getWidth(text);

			context.fill(4, 4, 6, 17, 0xFFE03030);
			context.fill(6, 4, width + 14, 17, 0x90000000);
			context.drawTextWithShadow(client.textRenderer, text, 10, 7, 0xFFFFFFFF);
		});
	}
}
