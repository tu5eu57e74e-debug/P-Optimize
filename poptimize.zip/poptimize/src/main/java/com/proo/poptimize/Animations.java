package com.proo.poptimize;

import net.minecraft.util.Identifier;

/** Sorts animated textures into the kinds that can be frozen one by one. */
public final class Animations {
	public static final int OTHER = 0;
	private static final int WATER = 1;
	private static final int LAVA = 2;
	private static final int FIRE = 3;
	private static final int PORTAL = 4;

	private Animations() {
	}

	public static int groupOf(Identifier sprite) {
		String path = sprite.getPath();

		if (path.startsWith("block/water_")) return WATER;
		if (path.startsWith("block/lava_")) return LAVA;
		if (path.equals("block/nether_portal")) return PORTAL;

		if (path.startsWith("block/") && (path.contains("fire_0") || path.contains("fire_1")
				|| path.endsWith("campfire_fire"))) {
			return FIRE;
		}

		return OTHER;
	}

	public static boolean frozen(int group) {
		return switch (group) {
			case WATER -> Config.on(Feature.NO_WATER_ANIMATION);
			case LAVA -> Config.on(Feature.NO_LAVA_ANIMATION);
			case FIRE -> Config.on(Feature.NO_FIRE_ANIMATION);
			case PORTAL -> Config.on(Feature.NO_PORTAL_ANIMATION);
			default -> false;
		};
	}
}
