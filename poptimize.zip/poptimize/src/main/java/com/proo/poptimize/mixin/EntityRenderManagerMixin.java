package com.proo.poptimize.mixin;

import com.proo.poptimize.Config;
import com.proo.poptimize.Feature;
import com.proo.poptimize.Culling;
import com.proo.poptimize.Occlusion;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderManager;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderManager.class)
public class EntityRenderManagerMixin {
	// Runs after vanilla's own check, so only entities that would be drawn are tested.
	@Inject(method = "shouldRender", at = @At("RETURN"), cancellable = true)
	private void poptimize$cull(Entity entity, Frustum frustum, double x, double y, double z,
			CallbackInfoReturnable<Boolean> cir) {
		if (!Config.enabled || !cir.getReturnValueZ()) return;

		if (Culling.isTooFar(entity, x, y, z) || (Config.on(Feature.CULL_HIDDEN) && Occlusion.isHidden(entity, x, y, z))) {
			cir.setReturnValue(false);
		}
	}
}
