package com.proo.poptimize.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.proo.poptimize.Config;
import com.proo.poptimize.Feature;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.InactivityFpsLimiter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/** Very low frame rate while the game is not focused, to save heat and battery. */
@Mixin(InactivityFpsLimiter.class)
public class InactivityFpsLimiterMixin {
	@ModifyReturnValue(method = "update", at = @At("RETURN"))
	private int poptimize$background(int original) {
		if (Config.on(Feature.BACKGROUND_FPS) && !MinecraftClient.getInstance().isWindowFocused()) {
			return Math.min(original, 10);
		}

		return original;
	}
}
