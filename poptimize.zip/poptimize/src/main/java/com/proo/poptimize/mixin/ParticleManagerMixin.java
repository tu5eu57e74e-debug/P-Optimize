package com.proo.poptimize.mixin;

import com.proo.poptimize.Config;
import com.proo.poptimize.Feature;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Item 23: limits how many new particles appear each tick. */
@Mixin(ParticleManager.class)
public class ParticleManagerMixin {
	@Unique
	private int poptimize$added;

	@Inject(method = "tick", at = @At("TAIL"))
	private void poptimize$reset(CallbackInfo ci) {
		this.poptimize$added = 0;
	}

	// The particle object is still created, it is just never queued. This is safe for
	// vanilla code that expects a non-null particle back.
	@Inject(method = "addParticle(Lnet/minecraft/client/particle/Particle;)V", at = @At("HEAD"), cancellable = true)
	private void poptimize$limit(Particle particle, CallbackInfo ci) {
		if (Config.on(Feature.LIMIT_PARTICLES) && ++this.poptimize$added > Config.preset.particlesPerTick) {
			ci.cancel();
		}
	}
}
