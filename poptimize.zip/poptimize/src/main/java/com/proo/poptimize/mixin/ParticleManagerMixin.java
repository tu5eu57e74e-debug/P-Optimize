package com.proo.poptimize.mixin;

import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import com.llamalad7.mixinextras.sugar.Local;
import com.proo.poptimize.Config;
import com.proo.poptimize.Feature;
import com.proo.poptimize.ParticleFilter;
import com.proo.poptimize.Setting;
import net.minecraft.client.particle.BlockDustParticle;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.particle.ParticleEffect;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Item 23: limits how many new particles appear each tick. */
@Mixin(ParticleManager.class)
public class ParticleManagerMixin {
	@Unique
	private int poptimize$added;

	@Inject(method = "tick", at = @At("TAIL"))
	private void poptimize$reset(CallbackInfo ci) {
		this.poptimize$added = 0;
	}

	// The particle object is still created, it is just never queued. This is safe for
	// vanilla code that expects a non-null particle back.
	@Inject(method = "addParticle(Lnet/minecraft/client/particle/Particle;)V", at = @At("HEAD"), cancellable = true)
	private void poptimize$limit(Particle particle, CallbackInfo ci) {
		// Breaking, mining and running dust is added here directly, without an effect.
		if (Config.on(Feature.NO_BLOCK_PARTICLES) && particle instanceof BlockDustParticle) {
			ci.cancel();
			return;
		}

		if (Config.on(Feature.LIMIT_PARTICLES)
				&& ++this.poptimize$added > Config.amount(Setting.PARTICLE_LIMIT)) {
			ci.cancel();
		}
	}

	// Same idea for whole kinds of particles: created, returned, never queued.
	@WrapWithCondition(
			method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;",
			require = 0, at = @At(value = "INVOKE",
					target = "Lnet/minecraft/client/particle/ParticleManager;addParticle(Lnet/minecraft/client/particle/Particle;)V"))
	private boolean poptimize$filter(ParticleManager manager, Particle particle,
			@Local(argsOnly = true) ParticleEffect effect) {
		return !Config.enabled || ParticleFilter.allow(effect);
	}
}
