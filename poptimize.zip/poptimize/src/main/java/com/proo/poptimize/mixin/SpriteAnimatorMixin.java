package com.proo.poptimize.mixin;

import com.proo.poptimize.AnimationTag;
import com.proo.poptimize.Animations;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Freezes the animation of one kind of texture. */
@Mixin(targets = "net.minecraft.client.texture.SpriteContents$Animator")
public class SpriteAnimatorMixin implements AnimationTag {
	@Unique
	private int poptimize$group = Animations.OTHER;
	@Unique
	private int poptimize$ticks;

	@Override
	public void poptimize$setGroup(int group) {
		this.poptimize$group = group;
	}

	@Inject(method = "tick", at = @At("HEAD"), cancellable = true, require = 0)
	private void poptimize$freeze(CallbackInfo ci) {
		// The first ticks always run, so the texture gets drawn once.
		if (this.poptimize$ticks < 2) {
			this.poptimize$ticks++;
		} else if (Animations.frozen(this.poptimize$group)) {
			ci.cancel();
		}
	}
}
