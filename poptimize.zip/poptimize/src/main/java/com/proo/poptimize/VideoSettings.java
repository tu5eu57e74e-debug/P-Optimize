package com.proo.poptimize;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.client.option.TextureFilteringMode;
import net.minecraft.client.render.ChunkBuilderMode;

import java.util.function.Function;

/** Vanilla video settings. Switching a feature off restores the player's old value. */
public final class VideoSettings {
	private VideoSettings() {
	}

	public static void apply(MinecraftClient client) {
		GameOptions options = client.options;

		// The last value is used in recording mode. null means "use the player's own setting".
		set(Feature.THREADED_CHUNKS, options.getChunkBuilderMode(), ChunkBuilderMode.NONE, null,
				ChunkBuilderMode::valueOf);
		set(Feature.SOLID_LEAVES, options.getCutoutLeaves(), false, true, Boolean::valueOf);
		set(Feature.NO_BIOME_BLEND, options.getBiomeBlendRadius(), 0, 5, Integer::valueOf);
		set(Feature.NO_CHUNK_FADE, options.getChunkFade(), 0.0, null, Double::valueOf);
		set(Feature.NO_TEXTURE_FILTER, options.getTextureFiltering(), TextureFilteringMode.NONE, null,
				TextureFilteringMode::valueOf);
		set(Feature.NO_TRANSPARENCY, options.getImprovedTransparency(), false, null, Boolean::valueOf);
		set(Feature.NO_ENTITY_SHADOWS, options.getEntityShadows(), false, true, Boolean::valueOf);
		set(Feature.NO_CLOUDS, options.getCloudRenderMode(), CloudRenderMode.OFF, CloudRenderMode.FANCY,
				CloudRenderMode::valueOf);
		set(Feature.NO_SMOOTH_LIGHT, options.getAo(), false, true, Boolean::valueOf);
		set(Feature.NO_VIGNETTE_BLUR, options.getVignette(), false, true, Boolean::valueOf);
		set("MENU_BLUR", Config.on(Feature.NO_VIGNETTE_BLUR), options.getMenuBackgroundBlurriness(), 0,
				Integer::valueOf);
		// The FPS limit feature was removed: give the player's old limit back.
		set("FPS_LIMIT", false, options.getMaxFps(), 0, Integer::valueOf);

		int renderDistance = Config.value(Setting.RENDER_DISTANCE);
		set("RENDER_DISTANCE", renderDistance != 0, options.getViewDistance(), renderDistance, Integer::valueOf);

		options.write();
		Config.applied = true;
		Config.save();
	}

	private static <T> void set(Feature feature, SimpleOption<T> option, T optimized, T recording,
			Function<String, T> parser) {
		if (Config.recording()) {
			set(feature.name(), recording != null, option, recording, parser);
		} else {
			set(feature.name(), Config.on(feature), option, optimized, parser);
		}
	}

	private static <T> void set(String key, boolean active, SimpleOption<T> option, T optimized,
			Function<String, T> parser) {
		String original = Config.original(key);

		if (active) {
			if (original == null) {
				T current = option.getValue();
				// Enums are saved by constant name so they can be parsed back.
				Config.setOriginal(key, current instanceof Enum<?> value ? value.name() : String.valueOf(current));
			}

			option.setValue(optimized);
		} else if (original != null) {
			try {
				option.setValue(parser.apply(original));
			} catch (IllegalArgumentException e) {
				POptimizeClient.LOGGER.warn("Could not restore {}", key, e);
			}

			Config.setOriginal(key, null);
		}
	}
}
