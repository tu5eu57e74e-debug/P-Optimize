package com.proo.poptimize;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.client.option.TextureFilteringMode;
import net.minecraft.client.render.ChunkBuilderMode;

import java.util.function.Function;

/** Vanilla video settings. Switching a feature off restores the player's old value. */
public final class VideoSettings {
	private VideoSettings() {
	}

	public static void apply(MinecraftClient client) {
		GameOptions options = client.options;

		set(Feature.THREADED_CHUNKS, options.getChunkBuilderMode(), ChunkBuilderMode.NONE, ChunkBuilderMode::valueOf);
		set(Feature.SOLID_LEAVES, options.getCutoutLeaves(), false, Boolean::valueOf);
		set(Feature.NO_BIOME_BLEND, options.getBiomeBlendRadius(), 0, Integer::valueOf);
		set(Feature.NO_CHUNK_FADE, options.getChunkFade(), 0.0, Double::valueOf);
		set(Feature.NO_TEXTURE_FILTER, options.getTextureFiltering(), TextureFilteringMode.NONE,
				TextureFilteringMode::valueOf);
		set(Feature.NO_TRANSPARENCY, options.getImprovedTransparency(), false, Boolean::valueOf);
		set(Feature.NO_ENTITY_SHADOWS, options.getEntityShadows(), false, Boolean::valueOf);
		set(Feature.NO_CLOUDS, options.getCloudRenderMode(), CloudRenderMode.OFF, CloudRenderMode::valueOf);
		set(Feature.FPS_LIMIT, options.getMaxFps(), Config.preset.maxFps, Integer::valueOf);

		options.write();
		Config.applied = true;
		Config.save();
	}

	private static <T> void set(Feature feature, SimpleOption<T> option, T optimized, Function<String, T> parser) {
		String original = Config.original(feature);

		if (Config.on(feature)) {
			if (original == null) {
				T current = option.getValue();
				// Enums are saved by constant name so they can be parsed back.
				Config.setOriginal(feature, current instanceof Enum<?> value ? value.name() : String.valueOf(current));
			}

			option.setValue(optimized);
		} else if (original != null) {
			try {
				option.setValue(parser.apply(original));
			} catch (IllegalArgumentException e) {
				POptimizeClient.LOGGER.warn("Could not restore {}", feature, e);
			}

			Config.setOriginal(feature, null);
		}
	}
}
