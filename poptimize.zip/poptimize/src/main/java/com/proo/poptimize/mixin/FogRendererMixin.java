package com.proo.poptimize.mixin;

import com.proo.poptimize.FogControl;
import net.minecraft.client.render.fog.FogRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Adjusts the fog distances right before they are sent to the graphics card. */
@Mixin(FogRenderer.class)
public class FogRendererMixin {
	@Unique
	private static final String SETUP = "applyFog(Lnet/minecraft/client/render/Camera;I"
			+ "Lnet/minecraft/client/render/RenderTickCounter;FLnet/minecraft/client/world/ClientWorld;)"
			+ "Lorg/joml/Vector4f;";
	@Unique
	private static final String WRITE = "Lnet/minecraft/client/render/fog/FogRenderer;"
			+ "applyFog(Ljava/nio/ByteBuffer;ILorg/joml/Vector4f;FFFFFF)V";

	@Inject(method = SETUP, at = @At("HEAD"), require = 0)
	private void poptimize$begin(CallbackInfoReturnable<?> cir) {
		FogControl.begin();
	}

	@ModifyArg(method = SETUP, at = @At(value = "INVOKE", target = WRITE), index = 3, require = 0)
	private float poptimize$environmentStart(float value) {
		return FogControl.environmentStart(value);
	}

	@ModifyArg(method = SETUP, at = @At(value = "INVOKE", target = WRITE), index = 4, require = 0)
	private float poptimize$environmentEnd(float value) {
		return FogControl.environmentEnd(value);
	}

	@ModifyArg(method = SETUP, at = @At(value = "INVOKE", target = WRITE), index = 5, require = 0)
	private float poptimize$edgeStart(float value) {
		return FogControl.edgeStart(value);
	}

	@ModifyArg(method = SETUP, at = @At(value = "INVOKE", target = WRITE), index = 6, require = 0)
	private float poptimize$edgeEnd(float value) {
		return FogControl.edgeEnd(value);
	}
}
