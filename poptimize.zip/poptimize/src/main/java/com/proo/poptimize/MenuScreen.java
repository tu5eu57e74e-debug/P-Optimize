package com.proo.poptimize;

import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * The in-game menu, drawn by hand. Uses tabs and pages so it fits small phone screens.
 * Every clickable area is recorded while drawing.
 */
public class MenuScreen extends Screen {
	private static final Identifier ICON = Identifier.of("poptimize", "icon.png");

	private static final int PANEL = 0xF2111117;
	private static final int CARD = 0xFF1C1C26;
	private static final int CARD_HOVER = 0xFF292937;
	private static final int TRACK_OFF = 0xFF43435A;
	private static final int WHITE = 0xFFFFFFFF;
	private static final int MUTED = 0xFFA4A4B8;

	private record Area(int x, int y, int width, int height, Runnable action) {
		boolean contains(double px, double py) {
			return px >= this.x && px < this.x + this.width && py >= this.y && py < this.y + this.height;
		}
	}

	private final Screen parent;
	private final List<Area> areas = new ArrayList<>();
	/** How far each switch knob has moved, from 0 (off) to 1 (on). */
	private final Map<Feature, Float> knobs = new EnumMap<>(Feature.class);

	private Feature.Category tab = Feature.Category.VIDEO;
	private int page;
	private int pages = 1;
	private boolean videoChanged;
	private long lastFrame;
	private float step;
	private int mouseX;
	private int mouseY;

	public MenuScreen(Screen parent) {
		super(Text.literal("P-Optimize"));
		this.parent = parent;
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		this.mouseX = mouseX;
		this.mouseY = mouseY;
		this.areas.clear();

		long now = Util.getMeasuringTimeMs();
		this.step = this.lastFrame == 0 ? 1.0F : Math.min(1.0F, (now - this.lastFrame) / 120.0F);
		this.lastFrame = now;

		int panelWidth = Math.min(390, this.width - 8);
		int panelHeight = Math.min(250, this.height - 8);
		int x = (this.width - panelWidth) / 2;
		int y = (this.height - panelHeight) / 2;

		context.fill(0, 0, this.width, this.height, 0x80000000);
		roundRect(context, x - 1, y - 1, panelWidth + 2, panelHeight + 2, Config.theme.main);
		roundRect(context, x, y, panelWidth, panelHeight, PANEL);

		drawHeader(context, x, y, panelWidth);
		drawTabs(context, x + 6, y + 34, panelWidth - 12);

		int top = y + 56;
		int bottom = y + panelHeight - 27;

		if (this.tab == Feature.Category.DISTANCE) {
			drawSettings(context, x + 6, top, panelWidth - 12, bottom - top);
		} else {
			drawFeatures(context, x + 6, top, panelWidth - 12, bottom - top);
		}

		drawFooter(context, x, y + panelHeight - 23, panelWidth);
	}

	private void drawHeader(DrawContext context, int x, int y, int width) {
		// Left to right gradient in the icon's colors.
		for (int offset = 0; offset < width; offset += 2) {
			int color = blend(Config.theme.dark, Config.theme.light, (float) offset / width);
			context.fill(x + offset, y, x + Math.min(offset + 2, width), y + 30, color);
		}

		context.fill(x, y + 30, x + width, y + 31, 0x60000000);
		context.fill(x + 5, y + 3, x + 29, y + 27, WHITE);
		context.drawTexture(RenderPipelines.GUI_TEXTURED, ICON, x + 6, y + 4, 0.0F, 0.0F, 22, 22, 22, 22);

		int textWidth = width - 36 - 76;
		drawFitted(context, this.title, x + 35, y + 6, textWidth, WHITE, false);
		Text subtitle = Text.literal("v1.3.0  |  " + this.client.getCurrentFps() + " FPS");
		drawFitted(context, subtitle, x + 35, y + 17, textWidth, 0xFFF0F0F0, false);

		// Master switch.
		int switchX = x + width - 30;
		Text state = Text.translatable(Config.enabled ? "poptimize.on" : "poptimize.off");
		drawFitted(context, state, switchX - 42, y + 11, 38, WHITE, true);
		roundRect(context, switchX - 1, y + 9, 24, 12, WHITE);
		roundRect(context, switchX, y + 10, 22, 10, Config.enabled ? 0xFF1FAF55 : TRACK_OFF);
		roundRect(context, switchX + (Config.enabled ? 13 : 1), y + 11, 8, 8, WHITE);

		this.areas.add(new Area(switchX - 44, y + 4, 70, 22, () -> {
			Config.enabled = !Config.enabled;
			this.videoChanged = true;
		}));
	}

	private void drawTabs(DrawContext context, int x, int y, int width) {
		Feature.Category[] tabs = Feature.Category.values();

		for (int i = 0; i < tabs.length; i++) {
			Feature.Category category = tabs[i];
			int left = x + i * width / tabs.length;
			int tabWidth = x + (i + 1) * width / tabs.length - left - 2;
			Text name = Text.translatable("poptimize.tab." + category.name().toLowerCase(Locale.ROOT));

			button(context, left, y, tabWidth, 17, name, this.tab == category, () -> {
				this.tab = category;
				this.page = 0;
			});
		}
	}

	/** A button in the grid that does something instead of switching a feature. */
	private record Action(Text label, Runnable run) {
	}

	private List<Action> actions() {
		if (this.tab != Feature.Category.TOOLS) return List.of();

		Text themeName = Text.translatable("poptimize.theme." + Config.theme.name().toLowerCase(Locale.ROOT));

		return List.of(
				new Action(Text.translatable("poptimize.action.hud"),
						() -> this.client.setScreen(new HudEditorScreen(this))),
				new Action(Text.translatable("poptimize.action.benchmark"), () -> {
					// Only makes sense inside a world.
					if (this.client.world != null) {
						Benchmark.start();
						this.client.setScreen(null);
					}
				}),
				new Action(Text.translatable("poptimize.action.theme", themeName), () -> {
					Theme[] themes = Theme.values();
					Config.theme = themes[(Config.theme.ordinal() + 1) % themes.length];
				}));
	}

	private void drawFeatures(DrawContext context, int x, int y, int width, int height) {
		List<Feature> features = new ArrayList<>();

		for (Feature feature : Feature.values()) {
			if (feature.category == this.tab) features.add(feature);
		}

		List<Action> actions = actions();
		int total = features.size() + actions.size();
		int rows = Math.max(1, height / 23);
		int perPage = rows * 2;
		setPages((total + perPage - 1) / perPage);

		int first = this.page * perPage;
		int cardWidth = (width - 3) / 2;

		for (int i = first; i < Math.min(total, first + perPage); i++) {
			int slot = i - first;
			int cardX = x + (slot % 2) * (cardWidth + 3);
			int cardY = y + (slot / 2) * 23;

			if (i < features.size()) {
				drawCard(context, features.get(i), cardX, cardY, cardWidth);
			} else {
				Action action = actions.get(i - features.size());
				button(context, cardX, cardY, cardWidth, 21, action.label(), true, action.run());
			}
		}
	}

	private void drawCard(DrawContext context, Feature feature, int x, int y, int width) {
		boolean on = Config.isChecked(feature);
		float target = on ? 1.0F : 0.0F;
		float position = this.knobs.getOrDefault(feature, target);
		position = position < target
				? Math.min(target, position + this.step)
				: Math.max(target, position - this.step);
		this.knobs.put(feature, position);

		Area area = new Area(x, y, width, 21, () -> {
			Config.toggle(feature);

			if (feature.category == Feature.Category.VIDEO || feature == Feature.RECORDING_MODE) {
				this.videoChanged = true;
			}
		});
		this.areas.add(area);

		roundRect(context, x, y, width, 21, area.contains(this.mouseX, this.mouseY) ? CARD_HOVER : CARD);
		context.fill(x, y + 3, x + 2, y + 18, blend(TRACK_OFF, Config.theme.light, position));

		drawFitted(context, Text.translatable(feature.translationKey()), x + 7, y + 7, width - 37,
				on ? WHITE : MUTED, false);

		int switchX = x + width - 27;
		roundRect(context, switchX, y + 5, 22, 11, blend(TRACK_OFF, Config.theme.main, position));
		roundRect(context, switchX + 1 + Math.round(position * 11), y + 6, 9, 9, WHITE);
	}

	private void drawSettings(DrawContext context, int x, int y, int width, int height) {
		Setting[] settings = Setting.values();
		int perPage = Math.max(1, height / 27);
		setPages((settings.length + perPage - 1) / perPage);

		int first = this.page * perPage;

		for (int i = first; i < Math.min(settings.length, first + perPage); i++) {
			Setting setting = settings[i];
			int rowY = y + (i - first) * 27;
			int[] choices = setting.choices();
			int choiceWidth = Math.min(36, width * 62 / 100 / choices.length);
			int choicesX = x + width - 4 - choiceWidth * choices.length;

			roundRect(context, x, rowY, width, 25, CARD);
			context.fill(x, rowY + 4, x + 2, rowY + 21, Config.selected(setting) != 0 ? Config.theme.light : TRACK_OFF);
			drawFitted(context, Text.translatable(setting.translationKey()), x + 7, rowY + 9,
					choicesX - x - 11, WHITE, false);

			for (int j = 0; j < choices.length; j++) {
				int value = choices[j];
				Text label = value == 0 ? Text.translatable("poptimize.off") : Text.literal(Integer.toString(value));

				button(context, choicesX + j * choiceWidth, rowY + 4, choiceWidth - 2, 17, label,
						Config.selected(setting) == value, () -> {
							Config.select(setting, value);
							if (setting == Setting.RENDER_DISTANCE) this.videoChanged = true;
						});
			}
		}
	}

	private void drawFooter(DrawContext context, int x, int y, int width) {
		Preset[] presets = Preset.values();
		int presetWidth = Math.min(46, (width - 130) / presets.length);

		for (int i = 0; i < presets.length; i++) {
			Preset preset = presets[i];
			Text name = Text.translatable("poptimize.preset." + preset.name().toLowerCase(Locale.ROOT));

			button(context, x + 6 + i * presetWidth, y, presetWidth - 2, 17, name, Config.preset == preset, () -> {
				Config.preset = preset;
				this.videoChanged = true;
			});
		}

		int doneX = x + width - 54;
		button(context, doneX, y, 48, 17, Text.translatable("gui.done"), true, this::close);

		if (this.pages > 1) {
			int middle = (x + 6 + presets.length * presetWidth + doneX) / 2;

			button(context, middle - 31, y, 17, 17, Text.literal("<"), false,
					() -> this.page = (this.page + this.pages - 1) % this.pages);
			drawFitted(context, Text.literal((this.page + 1) + "/" + this.pages), middle - 12, y + 5, 24, MUTED, true);
			button(context, middle + 14, y, 17, 17, Text.literal(">"), false,
					() -> this.page = (this.page + 1) % this.pages);
		}
	}

	private void setPages(int count) {
		this.pages = Math.max(1, count);
		this.page = Math.min(this.page, this.pages - 1);
	}

	private void button(DrawContext context, int x, int y, int width, int height, Text label, boolean selected,
			Runnable action) {
		Area area = new Area(x, y, width, height, action);
		this.areas.add(area);

		boolean hovered = area.contains(this.mouseX, this.mouseY);
		int color = selected
				? (hovered ? Config.theme.light : Config.theme.main)
				: (hovered ? CARD_HOVER : CARD);

		roundRect(context, x, y, width, height, color);
		drawFitted(context, label, x + 2, y + (height - 8) / 2, width - 4, selected ? WHITE : MUTED, true);
	}

	/** Draws text, shrinking it if it is wider than the space it has. */
	private void drawFitted(DrawContext context, Text text, int x, int y, int maxWidth, int color, boolean centered) {
		int textWidth = this.textRenderer.getWidth(text);
		if (textWidth <= 0 || maxWidth <= 0) return;

		float scale = Math.min(1.0F, (float) maxWidth / textWidth);
		float left = centered ? x + (maxWidth - textWidth * scale) / 2.0F : x;

		context.getMatrices().pushMatrix();
		context.getMatrices().translate(left, y + (1.0F - scale) * 4.0F);
		context.getMatrices().scale(scale, scale);
		context.drawTextWithShadow(this.textRenderer, text, 0, 0, color);
		context.getMatrices().popMatrix();
	}

	private static void roundRect(DrawContext context, int x, int y, int width, int height, int color) {
		context.fill(x + 1, y, x + width - 1, y + height, color);
		context.fill(x, y + 1, x + 1, y + height - 1, color);
		context.fill(x + width - 1, y + 1, x + width, y + height - 1, color);
	}

	/** Mixes two opaque colors. */
	private static int blend(int from, int to, float amount) {
		int result = 0xFF000000;

		for (int shift = 0; shift <= 16; shift += 8) {
			int a = (from >> shift) & 0xFF;
			int b = (to >> shift) & 0xFF;
			result |= Math.round(a + (b - a) * amount) << shift;
		}

		return result;
	}

	@Override
	public boolean mouseClicked(Click click, boolean doubled) {
		if (click.button() == 0) {
			for (Area area : this.areas) {
				if (area.contains(click.x(), click.y())) {
					ClickableWidget.playClickSound(this.client.getSoundManager());
					area.action().run();
					Config.save();
					return true;
				}
			}
		}

		return super.mouseClicked(click, doubled);
	}

	@Override
	public boolean mouseScrolled(double x, double y, double horizontal, double vertical) {
		if (this.pages > 1 && vertical != 0) {
			this.page = (this.page + (vertical < 0 ? 1 : this.pages - 1)) % this.pages;
			return true;
		}

		return super.mouseScrolled(x, y, horizontal, vertical);
	}

	@Override
	public void close() {
		this.client.setScreen(this.parent);
	}

	/** Called however the menu is left. Video settings are applied once, here. */
	@Override
	public void removed() {
		if (this.videoChanged) {
			this.videoChanged = false;
			VideoSettings.apply(this.client);
		}
	}
}
