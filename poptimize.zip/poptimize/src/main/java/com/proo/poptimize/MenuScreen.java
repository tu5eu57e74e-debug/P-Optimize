package com.proo.poptimize;

import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.Locale;

/** The in-game menu. Uses pages so it also fits small phone screens. */
public class MenuScreen extends Screen {
	private static final Identifier ICON = Identifier.of("poptimize", "icon.png");
	private static final int ROW = 22;
	private static final int TOP = 54;
	private static final int BOTTOM = 30;

	private final Screen parent;
	private int page;
	private int pages = 1;
	private boolean videoChanged;

	public MenuScreen(Screen parent) {
		super(Text.literal("P-Optimize"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		int columnWidth = Math.min(155, (this.width - 24) / 2);
		int left = this.width / 2 - columnWidth - 2;
		int right = this.width / 2 + 2;

		addButton(left, 28, columnWidth, onOff(Text.translatable("poptimize.menu.mod"), Config.enabled), () -> {
			Config.enabled = !Config.enabled;
			this.videoChanged = true;
		});

		Text presetName = Text.translatable("poptimize.preset." + Config.preset.name().toLowerCase(Locale.ROOT));
		addButton(right, 28, columnWidth, Text.translatable("poptimize.menu.preset", presetName), () -> {
			Preset[] presets = Preset.values();
			Config.preset = presets[(Config.preset.ordinal() + 1) % presets.length];
			this.videoChanged = true;
		});

		Feature[] features = Feature.values();
		int rows = Math.max(1, (this.height - TOP - BOTTOM) / ROW);
		int perPage = rows * 2;
		this.pages = (features.length + perPage - 1) / perPage;
		this.page = Math.min(this.page, this.pages - 1);

		int first = this.page * perPage;

		for (int i = first; i < Math.min(features.length, first + perPage); i++) {
			Feature feature = features[i];
			int slot = i - first;
			int x = slot % 2 == 0 ? left : right;
			int y = TOP + (slot / 2) * ROW;
			Text label = onOff(Text.translatable(feature.translationKey()), Config.isChecked(feature));

			addButton(x, y, columnWidth, label, () -> {
				Config.toggle(feature);
				if (feature.video) this.videoChanged = true;
			});
		}

		int bottomY = this.height - 25;

		if (this.pages > 1) {
			addButton(this.width / 2 - 104, bottomY, 40, Text.literal("<"),
					() -> this.page = (this.page + this.pages - 1) % this.pages);
			addButton(this.width / 2 + 64, bottomY, 40, Text.literal(">"),
					() -> this.page = (this.page + 1) % this.pages);
		}

		this.addDrawableChild(ButtonWidget.builder(Text.translatable("gui.done"), button -> this.close())
				.dimensions(this.width / 2 - 60, bottomY, 120, 20)
				.build());
	}

	/** Adds a button that runs the action, saves and redraws the menu. */
	private void addButton(int x, int y, int width, Text label, Runnable action) {
		this.addDrawableChild(ButtonWidget.builder(label, button -> {
			action.run();
			Config.save();
			this.clearAndInit();
		}).dimensions(x, y, width, 20).build());
	}

	private static Text onOff(Text name, boolean value) {
		Text state = Text.translatable(value ? "poptimize.on" : "poptimize.off");
		return Text.translatable("poptimize.menu.toggle", name, state);
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);

		int titleWidth = this.textRenderer.getWidth(this.title);
		int iconX = this.width / 2 - titleWidth / 2 - 22;

		context.drawTexture(RenderPipelines.GUI_TEXTURED, ICON, iconX, 6, 0.0F, 0.0F, 16, 16, 16, 16);
		context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 10, 0xFFFFFFFF);
	}

	@Override
	public void close() {
		this.client.setScreen(this.parent);
	}

	/** Called however the menu is left. Video settings are applied once, here. */
	@Override
	public void removed() {
		if (this.videoChanged) {
			this.videoChanged = false;
			VideoSettings.apply(this.client);
		}
	}
}
