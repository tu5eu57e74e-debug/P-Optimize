package com.proo.poptimize;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;

/**
 * Draws fewer chunks while the frame rate is below the target and brings them back once it is
 * reached again. The render distance of the game is not changed, so nothing has to reload.
 */
public final class SmartDistance {
	private static final int MIN_RADIUS = 4;
	/** Ticks between two looks at the frame rate. */
	private static final int CHECK_TICKS = 40;
	/** Ticks to wait after joining a world, while loading keeps the frame rate low. */
	private static final int SETTLE_TICKS = 300;
	/** Good looks in a row before one more ring of chunks is drawn. */
	private static final int GOOD_BEFORE_GROWING = 5;

	private static ClientWorld lastWorld;
	private static int wait;
	private static int good;
	/** Chunks currently drawn around the camera, or 0 while nothing is cut off. */
	private static int radius;
	private static int appliedRadius;
	private static int appliedVertical;

	private SmartDistance() {
	}

	public static int radius() {
		return Config.value(Setting.SMART_DRAW_FPS) == 0 ? 0 : radius;
	}

	public static void tick(MinecraftClient client) {
		ClientWorld world = client.world;

		if (world != lastWorld) {
			lastWorld = world;
			radius = 0;
			good = 0;
			wait = SETTLE_TICKS;
		}

		if (world == null) return;

		adjust(client);

		// Ask for a new list of sections whenever the limits change.
		int vertical = Config.value(Setting.VERTICAL_DISTANCE);

		if (radius() != appliedRadius || vertical != appliedVertical) {
			appliedRadius = radius();
			appliedVertical = vertical;
			client.worldRenderer.scheduleTerrainUpdate();
		}
	}

	private static void adjust(MinecraftClient client) {
		int target = Config.value(Setting.SMART_DRAW_FPS);

		if (target == 0) {
			radius = 0;
			good = 0;
			return;
		}

		// The frame rate says nothing while a menu is open or the game is in the background.
		if (client.currentScreen != null || !client.isWindowFocused() || AutoModes.away()) {
			wait = Math.max(wait, CHECK_TICKS);
			return;
		}

		if (--wait > 0) return;
		wait = CHECK_TICKS;

		int view = client.options.getClampedViewDistance();
		int current = radius == 0 ? view : Math.min(radius, view);
		// A target above the game's own frame rate limit could never be reached.
		int goal = Math.min(target, client.options.getMaxFps().getValue());
		int fps = client.getCurrentFps();

		if (fps < goal - 5) {
			current -= fps < goal * 2 / 3 ? 2 : 1;
			good = 0;
			// Give the new distance time before judging it.
			wait = CHECK_TICKS * 2;
		} else if (fps >= goal - 1) {
			if (++good >= GOOD_BEFORE_GROWING) {
				current++;
				good = 0;
			}
		} else {
			good = 0;
		}

		current = Math.max(MIN_RADIUS, current);
		radius = current >= view ? 0 : current;
	}
}
