package com.proo.poptimize.mixin;

import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import com.proo.poptimize.Config;
import com.proo.poptimize.Feature;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.feature.ArmorFeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.HeldItemFeatureRenderer;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/** Skips armor and held items on far entities. */
@Mixin(LivingEntityRenderer.class)
public class LivingEntityRendererMixin {
	@WrapWithCondition(method = "render", require = 0, at = @At(value = "INVOKE",
			target = "Lnet/minecraft/client/render/entity/feature/FeatureRenderer;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/client/render/entity/state/EntityRenderState;FF)V"))
	private boolean poptimize$skipEquipment(FeatureRenderer<?, ?> feature, MatrixStack matrices,
			OrderedRenderCommandQueue queue, int light, EntityRenderState state, float limbAngle,
			float limbDistance) {
		if (!Config.on(Feature.CULL_EQUIPMENT)) return true;

		double limit = Config.preset.nameDistance;
		if (state.squaredDistanceToCamera <= limit * limit) return true;

		return !(feature instanceof ArmorFeatureRenderer) && !(feature instanceof HeldItemFeatureRenderer);
	}
}
