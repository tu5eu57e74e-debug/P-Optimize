package com.proo.poptimize;

import net.minecraft.particle.ParticleEffect;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

/** Drops particles of some kinds. Anything not listed here is always shown. */
public final class ParticleFilter {
	private static int portals;

	private ParticleFilter() {
	}

	public static boolean allow(ParticleEffect effect) {
		Identifier id = Registries.PARTICLE_TYPE.getId(effect.getType());
		if (id == null || !id.getNamespace().equals("minecraft")) return true;

		Feature feature = switch (id.getPath()) {
			case "explosion", "explosion_emitter", "gust", "gust_emitter_large", "gust_emitter_small",
					"small_gust" -> Feature.NO_EXPLOSION_PARTICLES;
			case "effect", "instant_effect", "entity_effect", "witch" -> Feature.NO_POTION_PARTICLES;
			case "smoke", "large_smoke", "white_smoke", "poof" -> Feature.NO_SMOKE_PARTICLES;
			case "flame", "small_flame", "soul_fire_flame", "copper_fire_flame", "lava" ->
					Feature.NO_FLAME_PARTICLES;
			case "crit", "enchanted_hit", "damage_indicator", "sweep_attack" -> Feature.NO_HIT_PARTICLES;
			case "dripping_water", "falling_water", "dripping_lava", "falling_lava", "landing_lava",
					"dripping_honey", "falling_honey", "landing_honey", "dripping_obsidian_tear",
					"falling_obsidian_tear", "landing_obsidian_tear", "dripping_dripstone_water",
					"falling_dripstone_water", "dripping_dripstone_lava", "falling_dripstone_lava",
					"falling_nectar", "falling_spore_blossom" -> Feature.NO_DRIP_PARTICLES;
			case "enchant" -> Feature.NO_ENCHANT_PARTICLES;
			case "firework", "flash" -> Feature.NO_FIREWORK_PARTICLES;
			case "campfire_cosy_smoke", "campfire_signal_smoke" -> Feature.NO_CAMPFIRE_SMOKE;
			case "portal" -> Feature.FEWER_PORTAL_PARTICLES;
			default -> null;
		};

		if (feature == null || !Config.on(feature)) return true;

		// One portal particle out of four is kept.
		return feature == Feature.FEWER_PORTAL_PARTICLES && (portals++ & 3) == 0;
	}
}
