package com.proo.poptimize.mixin;

import com.proo.poptimize.Config;
import com.proo.poptimize.Feature;
import com.proo.poptimize.SoundLimit;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Stops ambient block effects: smoke, falling leaves, water and lava sounds. */
@Mixin(ClientWorld.class)
public class ClientWorldMixin {
	@Inject(method = "doRandomBlockDisplayTicks", at = @At("HEAD"), cancellable = true)
	private void poptimize$noAmbient(CallbackInfo ci) {
		if (Config.on(Feature.NO_AMBIENT)) {
			ci.cancel();
		}
	}

	@Inject(method = "playSound(DDDLnet/minecraft/sound/SoundEvent;Lnet/minecraft/sound/SoundCategory;FFZJ)V",
			at = @At("HEAD"), cancellable = true)
	private void poptimize$limitSounds(double x, double y, double z, SoundEvent event, SoundCategory category,
			float volume, float pitch, boolean useDistance, long seed, CallbackInfo ci) {
		if (Config.on(Feature.LIMIT_SOUNDS) && !SoundLimit.allow(event, category)) {
			ci.cancel();
		}
	}
}
