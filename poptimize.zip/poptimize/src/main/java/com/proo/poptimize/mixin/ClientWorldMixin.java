package com.proo.poptimize.mixin;

import com.proo.poptimize.Config;
import com.proo.poptimize.EntityTicking;
import com.proo.poptimize.Feature;
import com.proo.poptimize.SoundLimit;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Ambient block effects, sound limits and slower updates for far entities. */
@Mixin(ClientWorld.class)
public class ClientWorldMixin {
	@Inject(method = "doRandomBlockDisplayTicks", at = @At("HEAD"), cancellable = true)
	private void poptimize$noAmbient(CallbackInfo ci) {
		if (Config.on(Feature.NO_AMBIENT)) {
			ci.cancel();
		}
	}

	// The debris and smoke that explosions throw around.
	@Inject(method = "addBlockParticleEffects", at = @At("HEAD"), cancellable = true, require = 0)
	private void poptimize$noExplosionDebris(CallbackInfo ci) {
		if (Config.on(Feature.NO_EXPLOSION_PARTICLES)) {
			ci.cancel();
		}
	}

	@Inject(method = "playSound(DDDLnet/minecraft/sound/SoundEvent;Lnet/minecraft/sound/SoundCategory;FFZJ)V",
			at = @At("HEAD"), cancellable = true)
	private void poptimize$limitSounds(double x, double y, double z, SoundEvent event, SoundCategory category,
			float volume, float pitch, boolean useDistance, long seed, CallbackInfo ci) {
		if (!SoundLimit.allow(event, category)) {
			ci.cancel();
		}
	}

	@Inject(method = "tickEntity", at = @At("HEAD"), cancellable = true, require = 0)
	private void poptimize$slowFarEntities(Entity entity, CallbackInfo ci) {
		if (EntityTicking.shouldSkip(entity)) {
			// Keeps the entity drawn where it is and keeps its age counting.
			entity.resetPosition();
			entity.age++;
			ci.cancel();
		}
	}
}
