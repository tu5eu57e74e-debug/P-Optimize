package com.proo.poptimize.mixin;

import com.proo.poptimize.Config;
import com.proo.poptimize.Feature;
import net.minecraft.client.world.ClientWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Stops ambient block effects: smoke, falling leaves, water and lava sounds. */
@Mixin(ClientWorld.class)
public class ClientWorldMixin {
	@Inject(method = "doRandomBlockDisplayTicks", at = @At("HEAD"), cancellable = true)
	private void poptimize$noAmbient(CallbackInfo ci) {
		if (Config.on(Feature.NO_AMBIENT)) {
			ci.cancel();
		}
	}
}
