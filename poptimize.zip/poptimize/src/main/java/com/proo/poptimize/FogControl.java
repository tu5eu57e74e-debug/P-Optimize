package com.proo.poptimize;

/** Changes where the distance fog starts and ends. Only used from the render thread. */
public final class FogControl {
	private static final float FAR_START = 1.0E7F;
	private static final float FAR_END = 2.0E7F;

	/**
	 * True while the fog being set up is the normal open air fog. Water, lava, powder snow,
	 * blindness and darkness never count, so hiding fog gives no advantage there.
	 */
	private static boolean openAir;

	private FogControl() {
	}

	public static void begin() {
		openAir = false;
	}

	public static void openAir() {
		openAir = true;
	}

	private static boolean hidden() {
		return openAir && Config.on(Feature.NO_FOG);
	}

	public static float environmentStart(float original) {
		return hidden() ? FAR_START : original;
	}

	public static float environmentEnd(float original) {
		return hidden() ? FAR_END : original;
	}

	/** The fog moves closer with the smart draw distance, which hides the edge of the world. */
	public static float edgeStart(float original) {
		if (hidden()) return FAR_START;

		int radius = SmartDistance.radius();
		if (radius == 0) return original;

		float end = radius * 16.0F;
		return Math.min(original, end - Math.max(4.0F, Math.min(64.0F, end / 10.0F)));
	}

	public static float edgeEnd(float original) {
		if (hidden()) return FAR_END;

		int radius = SmartDistance.radius();
		return radius == 0 ? original : Math.min(original, radius * 16.0F);
	}
}
