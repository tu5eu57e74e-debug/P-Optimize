package com.proo.poptimize.mixin;

import com.proo.poptimize.AnimationTag;
import com.proo.poptimize.Animations;
import net.minecraft.client.texture.SpriteContents;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Tells a new animator which texture it belongs to. */
@Mixin(SpriteContents.class)
public class SpriteContentsMixin {
	@Shadow
	@Final
	private Identifier id;

	@Inject(method = "createAnimator", at = @At("RETURN"), require = 0)
	private void poptimize$tag(CallbackInfoReturnable<Object> cir) {
		if (cir.getReturnValue() instanceof AnimationTag tag) {
			tag.poptimize$setGroup(Animations.groupOf(this.id));
		}
	}
}
