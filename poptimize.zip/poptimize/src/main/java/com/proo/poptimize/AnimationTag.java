package com.proo.poptimize;

/** Added to every texture animator so it knows which kind of texture it moves. */
public interface AnimationTag {
	void poptimize$setGroup(int group);
}
