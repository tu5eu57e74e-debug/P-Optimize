package com.proo.poptimize;

import java.util.Locale;

/** Everything that has an on/off switch in the menu. */
public enum Feature {
	THREADED_CHUNKS(Category.VIDEO),
	SOLID_LEAVES(Category.VIDEO),
	NO_BIOME_BLEND(Category.VIDEO),
	NO_CHUNK_FADE(Category.VIDEO),
	NO_TEXTURE_FILTER(Category.VIDEO),
	NO_TRANSPARENCY(Category.VIDEO),
	NO_ENTITY_SHADOWS(Category.VIDEO),
	NO_CLOUDS(Category.VIDEO),
	NO_SMOOTH_LIGHT(Category.VIDEO),
	NO_VIGNETTE_BLUR(Category.VIDEO),

	CULL_MOBS(Category.HIDE),
	CULL_HIDDEN(Category.HIDE),
	CULL_PLAYERS(Category.HIDE, false),
	CULL_PLAYER_NAMES(Category.HIDE),
	CULL_NAMES(Category.HIDE),
	CULL_EQUIPMENT(Category.HIDE),
	CULL_ITEMS(Category.HIDE),
	CULL_XP(Category.HIDE),
	CULL_FRAMES(Category.HIDE),
	CULL_PAINTINGS(Category.HIDE),
	CULL_STANDS(Category.HIDE),
	CULL_CHESTS(Category.HIDE),
	CULL_DECORATIONS(Category.HIDE),
	CULL_CAMPFIRE_POTS(Category.HIDE),
	CULL_PISTONS(Category.HIDE),
	CULL_SIGN_TEXT(Category.HIDE),
	CULL_ENCHANT_BOOK(Category.HIDE),
	NO_SPAWNER_MOB(Category.HIDE),
	NO_BEACON_BEAM(Category.HIDE),

	LIMIT_PARTICLES(Category.EFFECTS),
	NO_AMBIENT(Category.EFFECTS),
	NO_WEATHER(Category.EFFECTS),
	NO_RAIN_SPLASH(Category.EFFECTS),
	NO_ANIMATIONS(Category.EFFECTS),
	LIMIT_SOUNDS(Category.EFFECTS),
	NO_FIRE(Category.EFFECTS),
	NO_TOASTS(Category.EFFECTS),
	CLEAR_FLUID_FOG(Category.EFFECTS, false),
	BACKGROUND_FPS(Category.EFFECTS),

	RECORDING_MODE(Category.TOOLS, false),
	FULLBRIGHT(Category.TOOLS, false),
	ZOOM_TOGGLE(Category.TOOLS),
	FPS_COUNTER(Category.TOOLS),
	COORDINATES(Category.TOOLS);

	/** The menu tabs. DISTANCE holds the settings in {@link Setting}. */
	public enum Category {
		VIDEO, HIDE, EFFECTS, DISTANCE, TOOLS
	}

	public final Category category;
	public final boolean defaultOn;

	Feature(Category category) {
		this(category, true);
	}

	Feature(Category category, boolean defaultOn) {
		this.category = category;
		this.defaultOn = defaultOn;
	}

	public String translationKey() {
		return "poptimize.feature." + name().toLowerCase(Locale.ROOT);
	}
}
