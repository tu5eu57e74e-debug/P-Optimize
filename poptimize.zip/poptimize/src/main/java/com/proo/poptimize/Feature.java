package com.proo.poptimize;

import java.util.Locale;

/** Everything that can be switched on or off in the menu. */
public enum Feature {
	THREADED_CHUNKS(true),
	SOLID_LEAVES(true),
	NO_BIOME_BLEND(true),
	NO_CHUNK_FADE(true),
	NO_TEXTURE_FILTER(true),
	NO_TRANSPARENCY(true),
	NO_ENTITY_SHADOWS(true),
	NO_CLOUDS(true),
	FPS_LIMIT(true),
	CULL_MOBS(false),
	CULL_HIDDEN(false),
	CULL_ITEMS(false),
	CULL_FRAMES(false),
	CULL_STANDS(false),
	CULL_NAMES(false),
	CULL_CHESTS(false),
	CULL_SIGN_TEXT(false),
	CULL_DECORATIONS(false),
	LIMIT_PARTICLES(false),
	NO_WEATHER(false),
	NO_ANIMATIONS(false);

	/** True if the feature changes a vanilla video setting. */
	public final boolean video;

	Feature(boolean video) {
		this.video = video;
	}

	public String translationKey() {
		return "poptimize.feature." + name().toLowerCase(Locale.ROOT);
	}
}
