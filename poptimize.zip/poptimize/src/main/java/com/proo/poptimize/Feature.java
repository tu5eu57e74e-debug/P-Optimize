package com.proo.poptimize;

import java.util.Locale;

/** Everything that has an on/off switch in the menu. */
public enum Feature {
	THREADED_CHUNKS(Category.VIDEO),
	SOLID_LEAVES(Category.VIDEO),
	NO_BIOME_BLEND(Category.VIDEO),
	NO_CHUNK_FADE(Category.VIDEO),
	NO_TEXTURE_FILTER(Category.VIDEO),
	NO_TRANSPARENCY(Category.VIDEO),
	NO_ENTITY_SHADOWS(Category.VIDEO),
	NO_CLOUDS(Category.VIDEO),
	NO_SMOOTH_LIGHT(Category.VIDEO),
	NO_VIGNETTE_BLUR(Category.VIDEO),
	FPS_LIMIT(Category.VIDEO),

	CULL_MOBS(Category.HIDE),
	CULL_HIDDEN(Category.HIDE),
	CULL_ITEMS(Category.HIDE),
	CULL_XP(Category.HIDE),
	CULL_FRAMES(Category.HIDE),
	CULL_PAINTINGS(Category.HIDE),
	CULL_STANDS(Category.HIDE),
	CULL_NAMES(Category.HIDE),
	CULL_CHESTS(Category.HIDE),
	CULL_DECORATIONS(Category.HIDE),
	CULL_SIGN_TEXT(Category.HIDE),
	CULL_ENCHANT_BOOK(Category.HIDE),
	NO_SPAWNER_MOB(Category.HIDE),
	NO_BEACON_BEAM(Category.HIDE),

	LIMIT_PARTICLES(Category.EFFECTS),
	NO_AMBIENT(Category.EFFECTS),
	NO_WEATHER(Category.EFFECTS),
	NO_RAIN_SPLASH(Category.EFFECTS),
	NO_ANIMATIONS(Category.EFFECTS),
	FPS_COUNTER(Category.EFFECTS);

	/** The menu tabs. DISTANCE holds the settings in {@link Setting}. */
	public enum Category {
		VIDEO, HIDE, EFFECTS, DISTANCE
	}

	public final Category category;

	Feature(Category category) {
		this.category = category;
	}

	public String translationKey() {
		return "poptimize.feature." + name().toLowerCase(Locale.ROOT);
	}
}
