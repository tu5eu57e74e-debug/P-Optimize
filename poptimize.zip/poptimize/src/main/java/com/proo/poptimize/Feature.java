package com.proo.poptimize;

import java.util.Locale;

/** Everything that has an on/off switch in the menu. */
public enum Feature {
	THREADED_CHUNKS(Category.VIDEO),
	SOLID_LEAVES(Category.VIDEO),
	NO_BIOME_BLEND(Category.VIDEO),
	NO_CHUNK_FADE(Category.VIDEO),
	NO_TEXTURE_FILTER(Category.VIDEO),
	NO_TRANSPARENCY(Category.VIDEO),
	NO_ENTITY_SHADOWS(Category.VIDEO),
	NO_CLOUDS(Category.VIDEO),
	NO_SMOOTH_LIGHT(Category.VIDEO),
	NO_VIGNETTE_BLUR(Category.VIDEO),

	CULL_MOBS(Category.ENTITIES),
	CULL_HIDDEN(Category.ENTITIES),
	CULL_PLAYERS(Category.ENTITIES, false),
	CULL_PLAYER_NAMES(Category.ENTITIES),
	CULL_NAMES(Category.ENTITIES),
	CULL_EQUIPMENT(Category.ENTITIES),
	CULL_ITEMS(Category.ENTITIES),
	CULL_XP(Category.ENTITIES),
	CULL_FRAMES(Category.ENTITIES),
	CULL_PAINTINGS(Category.ENTITIES),
	CULL_STANDS(Category.ENTITIES),
	FAR_ANIMATION(Category.ENTITIES),
	FAR_LAYERS(Category.ENTITIES),
	FAR_ITEM_SPIN(Category.ENTITIES),
	TWO_ITEM_COPIES(Category.ENTITIES),
	FAR_SKIN(Category.ENTITIES),
	FAR_FRAME_ITEMS(Category.ENTITIES),

	CULL_CHESTS(Category.BLOCKS),
	CULL_DECORATIONS(Category.BLOCKS),
	CULL_CAMPFIRE_POTS(Category.BLOCKS),
	CULL_PISTONS(Category.BLOCKS),
	CULL_SIGN_TEXT(Category.BLOCKS),
	CULL_ENCHANT_BOOK(Category.BLOCKS),
	NO_SPAWNER_MOB(Category.BLOCKS),
	NO_BEACON_BEAM(Category.BLOCKS),
	FAR_END_PORTAL(Category.BLOCKS),

	NO_SKY(Category.SKY, false),
	NO_STARS(Category.SKY, false),
	NO_SUN(Category.SKY, false),
	NO_MOON(Category.SKY, false),
	NO_FOG(Category.SKY, false),
	CLEAR_FLUID_FOG(Category.SKY, false),
	NO_WEATHER(Category.SKY),

	LIMIT_PARTICLES(Category.PARTICLES),
	NO_EXPLOSION_PARTICLES(Category.PARTICLES, false),
	NO_BLOCK_PARTICLES(Category.PARTICLES, false),
	NO_POTION_PARTICLES(Category.PARTICLES, false),
	NO_SMOKE_PARTICLES(Category.PARTICLES, false),
	NO_FLAME_PARTICLES(Category.PARTICLES, false),
	NO_HIT_PARTICLES(Category.PARTICLES, false),
	NO_DRIP_PARTICLES(Category.PARTICLES, false),
	NO_ENCHANT_PARTICLES(Category.PARTICLES, false),
	NO_FIREWORK_PARTICLES(Category.PARTICLES, false),
	NO_CAMPFIRE_SMOKE(Category.PARTICLES),
	FEWER_PORTAL_PARTICLES(Category.PARTICLES),
	NO_RAIN_SPLASH(Category.PARTICLES),
	NO_PARTICLE_PHYSICS(Category.PARTICLES, false),

	NO_ANIMATIONS(Category.EFFECTS),
	NO_WATER_ANIMATION(Category.EFFECTS, false),
	NO_LAVA_ANIMATION(Category.EFFECTS, false),
	NO_FIRE_ANIMATION(Category.EFFECTS, false),
	NO_PORTAL_ANIMATION(Category.EFFECTS, false),
	NO_AMBIENT(Category.EFFECTS),
	LIMIT_SOUNDS(Category.EFFECTS),
	NO_FIRE(Category.EFFECTS),
	NO_SCREEN_EFFECTS(Category.EFFECTS, false),
	NO_TOASTS(Category.EFFECTS),

	BACKGROUND_FPS(Category.SMART),

	RECORDING_MODE(Category.TOOLS, false),
	STREAMER_MODE(Category.TOOLS, false),
	FULLBRIGHT(Category.TOOLS, false),
	ZOOM_TOGGLE(Category.TOOLS),
	FPS_COUNTER(Category.TOOLS),
	COORDINATES(Category.TOOLS),
	TIMER(Category.TOOLS);

	/** The menu tabs. Features and {@link Setting}s are listed under one of them. */
	public enum Category {
		VIDEO, ENTITIES, BLOCKS, SKY, PARTICLES, EFFECTS, SMART, TOOLS
	}

	public final Category category;
	public final boolean defaultOn;

	Feature(Category category) {
		this(category, true);
	}

	Feature(Category category, boolean defaultOn) {
		this.category = category;
		this.defaultOn = defaultOn;
	}

	public String translationKey() {
		return "poptimize.feature." + name().toLowerCase(Locale.ROOT);
	}
}
