package com.proo.poptimize.mixin;

import com.proo.poptimize.Config;
import com.proo.poptimize.Culling;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.render.block.entity.BlockEntityRenderManager;
import net.minecraft.client.render.block.entity.state.BlockEntityRenderState;
import net.minecraft.client.render.command.ModelCommandRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Items 18 and 20: hides far chests, heads and banners. */
@Mixin(BlockEntityRenderManager.class)
public class BlockEntityRenderManagerMixin {
	@Inject(method = "getRenderState", at = @At("HEAD"), cancellable = true)
	private void poptimize$cull(BlockEntity blockEntity, float tickProgress,
			ModelCommandRenderer.CrumblingOverlayCommand crumblingOverlay,
			CallbackInfoReturnable<BlockEntityRenderState> cir) {
		if (Config.enabled && Culling.isTooFar(blockEntity)) {
			cir.setReturnValue(null);
		}
	}
}
