package com.proo.poptimize.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import com.proo.poptimize.Zoom;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
	// The boolean is true for the world view and false for the hand.
	@ModifyReturnValue(method = "getFov", at = @At("RETURN"), require = 0)
	private float poptimize$zoom(float original, @Local(argsOnly = true) boolean changingFov) {
		return Zoom.active && changingFov ? original / 4.0F : original;
	}
}
