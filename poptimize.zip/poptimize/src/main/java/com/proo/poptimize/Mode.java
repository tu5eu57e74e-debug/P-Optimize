package com.proo.poptimize;

import com.proo.poptimize.Feature.Category;

import java.util.Locale;

/** Ready-made groups of switches and settings. */
public enum Mode {
	PVP, FARMS, BUILDING, DEFAULTS;

	public String translationKey() {
		return "poptimize.mode." + name().toLowerCase(Locale.ROOT);
	}

	/**
	 * PvP, farms and building only change what is drawn and heard (the entity, block, sky, particle
	 * and effect tabs). DEFAULTS resets everything except the menu color, favorites and counter positions.
	 */
	public void apply() {
		for (Feature feature : Feature.values()) {
			if (this == DEFAULTS || changes(feature.category)) Config.set(feature, feature.defaultOn);
		}

		for (Setting setting : Setting.values()) {
			if (this == DEFAULTS || changes(setting.category)) Config.select(setting, setting.defaultValue);
		}

		switch (this) {
			case PVP -> {
				Config.preset = Preset.LOW;
				Config.set(Feature.CULL_EQUIPMENT, false);
				Config.set(Feature.FAR_ANIMATION, false);
				Config.set(Feature.FAR_LAYERS, false);
				Config.set(Feature.FAR_SKIN, false);
			}
			case FARMS -> {
				Config.preset = Preset.MEDIUM;
				Config.select(Setting.MOB_LIMIT, 40);
				Config.select(Setting.STACK_LIMIT, 6);
				Config.select(Setting.DROP_LIMIT, 32);
				Config.select(Setting.XP_LIMIT, 10);
				Config.select(Setting.ENTITY_TICK_DISTANCE, 32);
				Config.select(Setting.SAME_SOUND_LIMIT, 2);
				Config.select(Setting.SOUND_LIMIT, 20);
			}
			case BUILDING -> {
				Config.preset = Preset.LOW;
				Config.set(Feature.CULL_CHESTS, false);
				Config.set(Feature.CULL_DECORATIONS, false);
				Config.set(Feature.CULL_STANDS, false);
				Config.set(Feature.FULLBRIGHT, true);
			}
			case DEFAULTS -> Config.preset = Preset.MEDIUM;
		}
	}

	private static boolean changes(Category category) {
		return category == Category.ENTITIES || category == Category.BLOCKS || category == Category.SKY
				|| category == Category.PARTICLES || category == Category.EFFECTS;
	}
}
